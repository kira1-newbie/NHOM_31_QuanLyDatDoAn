package GUI;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class FrmDanhGiaDonHang extends JDialog {
    private static final int DEFAULT_RATING = 5;
    private static final int STAR_COUNT = 5;

    private static final Dimension DIALOG_SIZE = new Dimension(520, 460);
    private static final Dimension DIALOG_MIN_SIZE = new Dimension(470, 430);
    private static final Dimension CANCEL_BUTTON_SIZE = new Dimension(100, 40);
    private static final Dimension SUBMIT_BUTTON_SIZE = new Dimension(150, 40);

    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 26);
    private static final Font FONT_SECTION = new Font("Segoe UI", Font.BOLD, 16);
    private static final Font FONT_BODY = new Font("Segoe UI", Font.PLAIN, 14);
    private static final Font FONT_STAR = new Font("Segoe UI Symbol", Font.BOLD, 38);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    private final Color colorBg = new Color(15, 23, 42);
    private final Color colorCard = new Color(30, 41, 59);
    private final Color colorPrimary = new Color(249, 115, 22);
    private final Color colorMuted = new Color(148, 163, 184);
    private final Color colorBorder = new Color(71, 85, 105);
    private final Color colorStarOff = new Color(71, 85, 105);

    private int soSao = DEFAULT_RATING;
    private boolean daGui = false;
    private final JButton[] btnSao = new JButton[STAR_COUNT];
    private JTextArea txtNoiDung;
    private JLabel lblMoTaSao;

    /**
     * DTO nhỏ để trả dữ liệu đánh giá về form gọi dialog.
     * Dialog không tự ghi database để giữ đúng luồng GUI -> BLL -> DAO.
     */
    public static class KetQuaDanhGia {
        private final int soSao;
        private final String noiDung;

        public KetQuaDanhGia(int soSao, String noiDung) {
            this.soSao = soSao;
            this.noiDung = noiDung;
        }

        public int getSoSao() {
            return soSao;
        }

        public String getNoiDung() {
            return noiDung;
        }
    }

    public FrmDanhGiaDonHang(Window owner, String donHangId) {
        super(owner, "Đánh giá đơn hàng " + donHangId, ModalityType.APPLICATION_MODAL);
        initUI(donHangId);
    }

    public KetQuaDanhGia hienThi() {
        setVisible(true);
        if (!daGui) {
            return null;
        }
        return new KetQuaDanhGia(soSao, txtNoiDung.getText().trim());
    }

    private void initUI(String donHangId) {
        setSize(DIALOG_SIZE);
        setMinimumSize(DIALOG_MIN_SIZE);
        setLocationRelativeTo(getOwner());
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(colorBg);

        JPanel pnlRoot = taoPanelRoot();
        pnlRoot.add(taoHeader(donHangId), BorderLayout.NORTH);
        pnlRoot.add(taoNoiDung(), BorderLayout.CENTER);
        pnlRoot.add(taoThanhNut(), BorderLayout.SOUTH);
        add(pnlRoot, BorderLayout.CENTER);

        capNhatSao(DEFAULT_RATING);
    }

    private JPanel taoPanelRoot() {
        JPanel panel = new JPanel(new BorderLayout(0, 18));
        panel.setBackground(colorBg);
        panel.setBorder(new EmptyBorder(22, 24, 20, 24));
        return panel;
    }

    private JPanel taoHeader(String donHangId) {
        JPanel panel = new JPanel(new BorderLayout(0, 6));
        panel.setOpaque(false);

        JLabel lblTitle = new JLabel("Đánh giá đơn hàng");
        lblTitle.setFont(FONT_TITLE);
        lblTitle.setForeground(Color.WHITE);
        panel.add(lblTitle, BorderLayout.NORTH);

        JLabel lblOrder = new JLabel("Mã đơn: " + donHangId);
        lblOrder.setFont(FONT_BODY);
        lblOrder.setForeground(colorMuted);
        panel.add(lblOrder, BorderLayout.CENTER);

        return panel;
    }

    private JPanel taoNoiDung() {
        JPanel panel = new JPanel(new BorderLayout(0, 18));
        panel.setBackground(colorCard);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(51, 65, 85), 1),
                new EmptyBorder(18, 18, 18, 18)
        ));

        panel.add(taoKhuVucSao(), BorderLayout.NORTH);
        panel.add(taoKhuVucNhanXet(), BorderLayout.CENTER);
        return panel;
    }

    private JPanel taoKhuVucSao() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setOpaque(false);

        JLabel lblStarTitle = new JLabel("Bạn hài lòng thế nào?");
        lblStarTitle.setFont(FONT_SECTION);
        lblStarTitle.setForeground(Color.WHITE);
        panel.add(lblStarTitle, BorderLayout.NORTH);

        JPanel pnlStars = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        pnlStars.setOpaque(false);
        for (int i = 0; i < btnSao.length; i++) {
            final int value = i + 1;
            JButton btn = new JButton("★");
            btn.setFont(FONT_STAR);
            btn.setBorder(BorderFactory.createEmptyBorder(0, 2, 0, 2));
            btn.setContentAreaFilled(false);
            btn.setFocusPainted(false);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.addActionListener(e -> capNhatSao(value));
            btnSao[i] = btn;
            pnlStars.add(btn);
        }
        panel.add(pnlStars, BorderLayout.CENTER);

        lblMoTaSao = new JLabel();
        lblMoTaSao.setFont(FONT_BODY);
        lblMoTaSao.setForeground(colorMuted);
        panel.add(lblMoTaSao, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel taoKhuVucNhanXet() {
        JPanel panel = new JPanel(new BorderLayout(0, 8));
        panel.setOpaque(false);

        JLabel lblComment = new JLabel("Nhận xét");
        lblComment.setFont(FONT_SECTION);
        lblComment.setForeground(Color.WHITE);
        panel.add(lblComment, BorderLayout.NORTH);

        txtNoiDung = new JTextArea();
        txtNoiDung.setFont(FONT_BODY);
        txtNoiDung.setLineWrap(true);
        txtNoiDung.setWrapStyleWord(true);
        txtNoiDung.setRows(7);
        txtNoiDung.setForeground(Color.WHITE);
        txtNoiDung.setCaretColor(Color.WHITE);
        txtNoiDung.setBackground(colorBg);
        txtNoiDung.setBorder(new EmptyBorder(10, 12, 10, 12));

        JScrollPane scrollPane = new JScrollPane(txtNoiDung);
        scrollPane.setBorder(BorderFactory.createLineBorder(colorBorder, 1));
        scrollPane.getViewport().setBackground(colorBg);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel taoThanhNut() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        panel.setOpaque(false);

        JButton btnHuy = new JButton("Hủy");
        styleButton(btnHuy, colorCard, colorBorder, CANCEL_BUTTON_SIZE);
        btnHuy.addActionListener(e -> dispose());

        JButton btnGui = new JButton("Gửi đánh giá");
        styleButton(btnGui, colorPrimary, colorPrimary, SUBMIT_BUTTON_SIZE);
        btnGui.addActionListener(e -> {
            daGui = true;
            dispose();
        });

        panel.add(btnHuy);
        panel.add(btnGui);
        getRootPane().setDefaultButton(btnGui);
        return panel;
    }

    /**
     * Cập nhật màu sao và mô tả mỗi khi người dùng chọn mức đánh giá.
     */
    private void capNhatSao(int soSaoMoi) {
        soSao = soSaoMoi;
        for (int i = 0; i < btnSao.length; i++) {
            btnSao[i].setForeground(i < soSao ? colorPrimary : colorStarOff);
        }
        lblMoTaSao.setText(soSao + "/5 - " + layMoTaSao(soSao));
    }

    private String layMoTaSao(int value) {
        switch (value) {
            case 1:
                return "Rất không hài lòng";
            case 2:
                return "Chưa hài lòng";
            case 3:
                return "Tạm ổn";
            case 4:
                return "Hài lòng";
            default:
                return "Rất hài lòng";
        }
    }

    private static void styleButton(JButton btn, Color bg, Color border, Dimension size) {
        btn.setFont(FONT_BUTTON);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createLineBorder(border, 1));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(size);
    }
}
