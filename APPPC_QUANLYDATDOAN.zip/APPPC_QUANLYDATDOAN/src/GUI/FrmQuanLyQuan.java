package GUI;

import BusinessLogic.SanPhamBLL;
import SCHEMA.NguoiDung;
import SCHEMA.SanPham;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class FrmQuanLyQuan extends JFrame {

    private NguoiDung currentUser;
    private SanPhamBLL sanPhamBLL = new SanPhamBLL();

    // UI Components
    private JTextField txtMaSP, txtTenSP, txtGia;
    private JComboBox<String> cbTrangThai;
    private JTable tableMenu;
    private DefaultTableModel tableModel;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi;

    private final Color COLOR_PRIMARY = new Color(238, 77, 45);

    public FrmQuanLyQuan(NguoiDung user) {
        this.currentUser = user;
        initUI();
        loadData();
    }

    private void initUI() {
        setTitle("Quản Lý Thực Đơn Quán Ăn");
        setSize(1000, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(Color.WHITE);

        // Header
        JLabel lblTitle = new JLabel("🏪 QUẢN LÝ THỰC ĐƠN", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(COLOR_PRIMARY);
        lblTitle.setBorder(new EmptyBorder(15, 0, 15, 0));
        add(lblTitle, BorderLayout.NORTH);

        // Panel Bên Trái: Form Nhập Liệu
        JPanel pnlInput = new JPanel(new GridLayout(5, 2, 10, 20));
        pnlInput.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY), "Thông tin món ăn",
                TitledBorder.LEFT, TitledBorder.TOP, new Font("Segoe UI", Font.BOLD, 14)));
        pnlInput.setBackground(Color.WHITE);
        pnlInput.setPreferredSize(new Dimension(350, 0));

        pnlInput.add(new JLabel("Mã Sản Phẩm:"));
        txtMaSP = new JTextField();
        pnlInput.add(txtMaSP);

        pnlInput.add(new JLabel("Tên Món Ăn:"));
        txtTenSP = new JTextField();
        pnlInput.add(txtTenSP);

        pnlInput.add(new JLabel("Giá Bán (VNĐ):"));
        txtGia = new JTextField();
        pnlInput.add(txtGia);

        pnlInput.add(new JLabel("Trạng Thái:"));
        cbTrangThai = new JComboBox<>(new String[]{"CÒN HÀNG", "HẾT HÀNG"});
        pnlInput.add(cbTrangThai);

        // Nút chức năng
        JPanel pnlButtons = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        pnlButtons.setBackground(Color.WHITE);
        btnThem = createButton("Thêm");
        btnSua = createButton("Sửa");
        btnXoa = createButton("Xóa");
        btnLamMoi = createButton("Mới");

        pnlButtons.add(btnThem); pnlButtons.add(btnSua);
        pnlButtons.add(btnXoa); pnlButtons.add(btnLamMoi);
        pnlInput.add(pnlButtons);

        add(pnlInput, BorderLayout.WEST);

        // Panel Bên Phải: Bảng Dữ Liệu
        String[] columns = {"Mã SP", "Tên Món", "Giá Bán", "Trạng Thái"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tableMenu = new JTable(tableModel);
        tableMenu.setRowHeight(25);

        // Bắt sự kiện click vào bảng để đưa dữ liệu ngược lên Form
        tableMenu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                int row = tableMenu.getSelectedRow();
                if(row >= 0) {
                    txtMaSP.setText(tableModel.getValueAt(row, 0).toString());
                    txtTenSP.setText(tableModel.getValueAt(row, 1).toString());
                    txtGia.setText(tableModel.getValueAt(row, 2).toString());
                    cbTrangThai.setSelectedItem(tableModel.getValueAt(row, 3).toString());
                    txtMaSP.setEnabled(false); // Không cho sửa Khóa Chính
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(tableMenu);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Danh sách món ăn"));
        scrollPane.setBackground(Color.WHITE);
        add(scrollPane, BorderLayout.CENTER);

        addEvents(); // Gắn sự kiện cho các nút
    }

    private JButton createButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(COLOR_PRIMARY);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        return btn;
    }

    private void loadData() {
        tableModel.setRowCount(0);
        List<SanPham> list = sanPhamBLL.layDanhSachMenu();
        for (SanPham sp : list) {
            // Lọc chỉ hiện các món của đúng quán này (Giả lập QuanAnId từ KhachHangId)
            String quanAnId = "QA" + currentUser.getNguoiDungId().substring(3);
            if (sp.getQuanAnId().equals(quanAnId)) {
                tableModel.addRow(new Object[]{sp.getSanPhamId(), sp.getTenSanPham(), sp.getGia(), sp.getTrangThai()});
            }
        }
    }
    /**
     * Gắn sự kiện cho các nút chức năng trên Form
     */
    private void addEvents() {
        // 1. Nút Làm Mới: Xóa trắng các ô nhập liệu và bỏ chọn bảng
        btnLamMoi.addActionListener(e -> {
            txtMaSP.setText("");
            txtTenSP.setText("");
            txtGia.setText("");
            txtMaSP.setEnabled(true); // Cho phép nhập lại Mã SP khi thêm mới
            cbTrangThai.setSelectedIndex(0);
            tableMenu.clearSelection();
        });

        // 2. Nút Thêm: Đã hoàn thiện ở bước trước
        btnThem.addActionListener(e -> {
            try {
                SanPham sp = new SanPham();
                sp.setSanPhamId(txtMaSP.getText().trim());
                sp.setQuanAnId("QA" + currentUser.getNguoiDungId().substring(3)); // Giả lập mã quán
                sp.setDanhMucId(1);
                sp.setTenSanPham(txtTenSP.getText().trim());
                sp.setGia(Double.parseDouble(txtGia.getText().trim()));
                sp.setTrangThai(cbTrangThai.getSelectedItem().toString());

                if (sanPhamBLL.themSanPham(sp)) {
                    JOptionPane.showMessageDialog(this, "Thêm món thành công!");
                    loadData(); // Tải lại bảng để thấy dữ liệu mới
                    btnLamMoi.doClick(); // Làm sạch form
                } else {
                    JOptionPane.showMessageDialog(this, "Mã sản phẩm đã tồn tại hoặc lỗi dữ liệu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Vui lòng nhập giá là một số hợp lệ!", "Lỗi nhập liệu", JOptionPane.WARNING_MESSAGE);
            }
        });

        // 3. Nút Sửa: Cập nhật thông tin món ăn đang chọn
        btnSua.addActionListener(e -> {
            // Kiểm tra xem người dùng đã chọn dòng nào trên bảng chưa
            int row = tableMenu.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn một món ăn trên bảng để sửa!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            try {
                // Thu thập dữ liệu từ giao diện
                SanPham sp = new SanPham();
                sp.setSanPhamId(txtMaSP.getText().trim()); // Khóa chính dùng để tìm bản ghi
                sp.setTenSanPham(txtTenSP.getText().trim());
                sp.setGia(Double.parseDouble(txtGia.getText().trim()));
                sp.setTrangThai(cbTrangThai.getSelectedItem().toString());

                // Gọi BLL để xử lý
                if (sanPhamBLL.capNhatSanPham(sp)) {
                    JOptionPane.showMessageDialog(this, "Cập nhật món ăn thành công!");
                    loadData(); // Tải lại bảng
                } else {
                    JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật. Vui lòng thử lại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Giá bán phải là một số hợp lệ!", "Lỗi nhập liệu", JOptionPane.WARNING_MESSAGE);
            }
        });

        // 4. Nút Xóa: Xóa món ăn khỏi CSDL
        btnXoa.addActionListener(e -> {
            // Kiểm tra xem người dùng đã chọn dòng nào trên bảng chưa
            int row = tableMenu.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn một món ăn trên bảng để xóa!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String maSP = txtMaSP.getText().trim();
            String tenSP = txtTenSP.getText().trim();

            // Hiển thị cảnh báo trước khi xóa
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Bạn có chắc chắn muốn xóa món '" + tenSP + "' không?",
                    "Xác nhận xóa", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                // Gọi BLL để xử lý
                if (sanPhamBLL.xoaSanPham(maSP)) {
                    JOptionPane.showMessageDialog(this, "Đã xóa món ăn thành công!");
                    loadData(); // Tải lại bảng
                    btnLamMoi.doClick(); // Xóa trắng form nhập liệu
                } else {
                    JOptionPane.showMessageDialog(this,
                            "Không thể xóa món ăn này!\nNguyên nhân: Món ăn có thể đang nằm trong lịch sử đơn hàng của khách.",
                            "Lỗi ràng buộc dữ liệu", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }
}