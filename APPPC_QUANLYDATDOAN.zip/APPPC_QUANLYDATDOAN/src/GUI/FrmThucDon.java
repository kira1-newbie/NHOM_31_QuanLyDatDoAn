package GUI;

import BusinessLogic.GioHangBLL;
import BusinessLogic.SanPhamBLL;
import SCHEMA.NguoiDung;
import SCHEMA.SanPham;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.List;

public class FrmThucDon extends JFrame {

    // --- Biến lưu trữ thông tin người dùng đang đăng nhập ---
    private NguoiDung currentUser;

    // --- Khởi tạo các lớp Business Logic (BLL) ---
    private SanPhamBLL sanPhamBLL = new SanPhamBLL();
    private GioHangBLL gioHangBLL = new GioHangBLL();

    // --- Các thành phần Giao diện chính ---
    private JPanel pnlMenuContainer;

    // --- Bảng màu chuẩn của FoodApp ---
    private final Color COLOR_BG = new Color(245, 246, 250);     // Màu nền xám nhạt
    private final Color COLOR_PRIMARY = new Color(238, 77, 45);  // Màu cam chủ đạo
    private final Color COLOR_TEXT = new Color(50, 50, 50);      // Màu chữ tối

    /**
     * Hàm khởi tạo Form Thực Đơn
     * @param user Đối tượng người dùng được truyền từ FrmMain sang
     */
    public FrmThucDon(NguoiDung user) {
        this.currentUser = user;
        initUI();       // Bước 1: Vẽ khung giao diện
        loadData();     // Bước 2: Nạp dữ liệu món ăn từ CSDL
    }

    /**
     * Khởi tạo giao diện (Khung cửa sổ, Header, Thanh cuộn)
     */
    private void initUI() {
        setTitle("Thực Đơn Hôm Nay - Xin chào " + currentUser.getHoTen());
        setSize(950, 650);
        setLocationRelativeTo(null); // Hiển thị ở giữa màn hình
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Chỉ đóng form này, không thoát toàn bộ app
        getContentPane().setBackground(COLOR_BG);
        setLayout(new BorderLayout());

        // ==========================================
        // 1. PHẦN HEADER (Tiêu đề và nút mở Giỏ Hàng)
        // ==========================================
        JPanel pnlHeader = new JPanel(new BorderLayout());
        pnlHeader.setBackground(Color.WHITE);
        pnlHeader.setBorder(new EmptyBorder(15, 20, 15, 20)); // Tạo khoảng cách (Padding)

        JLabel lblTitle = new JLabel("🔥 Danh Sách Món Ăn");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitle.setForeground(COLOR_PRIMARY);
        pnlHeader.add(lblTitle, BorderLayout.WEST);

        JButton btnXemGioHang = new JButton("🛒 Xem Giỏ Hàng");
        btnXemGioHang.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnXemGioHang.setBackground(COLOR_PRIMARY);
        btnXemGioHang.setForeground(Color.WHITE);
        btnXemGioHang.setFocusPainted(false);
        btnXemGioHang.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Sự kiện khi bấm nút "Xem Giỏ Hàng"
        btnXemGioHang.addActionListener(e -> {
            // Hiển thị thông báo tạm thời (Chúng ta sẽ code FrmGioHang sau)
            JOptionPane.showMessageDialog(this, "Chức năng Giỏ hàng đang được mở...");
            // new FrmGioHang(currentUser).setVisible(true);
        });

        pnlHeader.add(btnXemGioHang, BorderLayout.EAST);
        add(pnlHeader, BorderLayout.NORTH);

        // ==========================================
        // 2. PHẦN NỘI DUNG CHÍNH (Danh sách món ăn)
        // ==========================================

        // Sử dụng GridLayout(0, 3) -> 0 dòng (tự do tăng), 3 cột, khoảng cách ngang/dọc là 20px
        pnlMenuContainer = new JPanel(new GridLayout(0, 3, 20, 20));
        pnlMenuContainer.setBackground(COLOR_BG);
        pnlMenuContainer.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Đưa panel chứa món ăn vào một thanh cuộn (JScrollPane)
        JScrollPane scrollPane = new JScrollPane(pnlMenuContainer);
        scrollPane.setBorder(null); // Xóa viền xấu của thanh cuộn
        scrollPane.getVerticalScrollBar().setUnitIncrement(16); // Giúp cuộn chuột mượt mà hơn

        add(scrollPane, BorderLayout.CENTER);
    }

    /**
     * Tải dữ liệu từ CSDL thông qua BLL và hiển thị lên giao diện
     */
    private void loadData() {
        pnlMenuContainer.removeAll(); // Xóa sạch các món ăn cũ trên màn hình

        // Gọi tầng BLL để lấy danh sách
        List<SanPham> danhSachSP = sanPhamBLL.layDanhSachMenu();

        // Kiểm tra nếu quán chưa có món nào
        if (danhSachSP == null || danhSachSP.isEmpty()) {
            JLabel lblEmpty = new JLabel("Hiện tại chưa có món ăn nào được bán.");
            lblEmpty.setFont(new Font("Segoe UI", Font.ITALIC, 16));
            pnlMenuContainer.add(lblEmpty);
        } else {
            // Duyệt qua từng sản phẩm trong danh sách
            for (SanPham sp : danhSachSP) {
                // Tạo một cái "thẻ" (Card) cho sản phẩm đó và thêm vào Container
                pnlMenuContainer.add(createProductCard(sp));
            }
        }

        // Làm mới lại giao diện để hiển thị các thay đổi
        pnlMenuContainer.revalidate();
        pnlMenuContainer.repaint();
    }

    /**
     * Tạo một "thẻ" (Panel) chứa thông tin của 1 Sản Phẩm
     * @param sp Đối tượng SanPham chứa dữ liệu
     * @return JPanel đã được thiết kế hoàn chỉnh
     */
    private JPanel createProductCard(SanPham sp) {
        // Dùng lớp RoundedPanel tự viết để bo góc thẻ
        RoundedPanel card = new RoundedPanel(20, Color.WHITE);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS)); // Xếp các thành phần từ trên xuống dưới
        card.setBorder(new EmptyBorder(15, 15, 15, 15));

        // 1. Tên món ăn (Dùng HTML để chữ tự động rớt dòng nếu quá dài)
        JLabel lblName = new JLabel("<html><body style='text-align: center; width: 200px;'>" + sp.getTenSanPham() + "</body></html>");
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblName.setForeground(COLOR_TEXT);
        lblName.setAlignmentX(Component.CENTER_ALIGNMENT); // Căn giữa

        // 2. Giá tiền (Định dạng #,### VNĐ)
        DecimalFormat df = new DecimalFormat("#,###");
        JLabel lblPrice = new JLabel(df.format(sp.getGia()) + " VNĐ");
        lblPrice.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblPrice.setForeground(COLOR_PRIMARY);
        lblPrice.setAlignmentX(Component.CENTER_ALIGNMENT);

        // 3. Vùng chọn số lượng
        JPanel pnlQuantity = new JPanel(new FlowLayout(FlowLayout.CENTER));
        pnlQuantity.setOpaque(false);
        pnlQuantity.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblSL = new JLabel("Số lượng:");
        lblSL.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        // JSpinner cho phép tăng/giảm số lượng (Mặc định 1, min 1, max 50)
        SpinnerModel spinnerModel = new SpinnerNumberModel(1, 1, 50, 1);
        JSpinner spinSoLuong = new JSpinner(spinnerModel);
        spinSoLuong.setPreferredSize(new Dimension(60, 30));
        spinSoLuong.setFont(new Font("Segoe UI", Font.BOLD, 14));

        pnlQuantity.add(lblSL);
        pnlQuantity.add(spinSoLuong);

        // 4. Nút Thêm vào giỏ
        JButton btnAdd = new JButton("Thêm vào giỏ");
        btnAdd.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnAdd.setBackground(Color.WHITE);
        btnAdd.setForeground(COLOR_PRIMARY);
        btnAdd.setBorder(BorderFactory.createLineBorder(COLOR_PRIMARY, 2)); // Viền cam
        btnAdd.setFocusPainted(false);
        btnAdd.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnAdd.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnAdd.setMaximumSize(new Dimension(160, 40));

        // Hiệu ứng Hover: Khi di chuột vào nút sẽ đổi sang nền cam, chữ trắng
        btnAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnAdd.setBackground(COLOR_PRIMARY);
                btnAdd.setForeground(Color.WHITE);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnAdd.setBackground(Color.WHITE);
                btnAdd.setForeground(COLOR_PRIMARY);
            }
        });

        // SỰ KIỆN: Khi bấm "Thêm vào giỏ"
        btnAdd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int soLuong = (int) spinSoLuong.getValue();

                // MÔ PHỎNG TẠO MÃ GIỎ HÀNG:
                // Vì database thiết kế 1 Khách Hàng chỉ có 1 giỏ hàng duy nhất tại 1 thời điểm.
                // Để đơn giản, ta lấy 4 số cuối của NguoiDungId ghép với "GH". VD: USR0001 -> GH0001
                String gioHangId = "GH" + currentUser.getNguoiDungId().substring(3);

                // GỌI BLL ĐỂ XỬ LÝ
                boolean success = gioHangBLL.themVaoGio(gioHangId, sp.getSanPhamId(), soLuong);

                if (success) {
                    JOptionPane.showMessageDialog(card, "Đã thêm " + soLuong + " x [" + sp.getTenSanPham() + "] vào giỏ hàng!", "Thành công", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(card, "Lỗi khi thêm vào giỏ. Vui lòng thử lại.", "Lỗi hệ thống", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // 5. Thêm tất cả vào thẻ (Card)
        card.add(Box.createVerticalStrut(15)); // Khoảng trống phía trên
        card.add(lblName);
        card.add(Box.createVerticalStrut(10));
        card.add(lblPrice);
        card.add(Box.createVerticalStrut(10));
        card.add(pnlQuantity);
        card.add(Box.createVerticalStrut(15));
        card.add(btnAdd);
        card.add(Box.createVerticalStrut(15)); // Khoảng trống phía dưới

        return card;
    }

    // ==========================================================
    // LỚP TIỆN ÍCH TẠO PANEL BO GÓC BÊN TRONG (INNER CLASS)
    // ==========================================================
    class RoundedPanel extends JPanel {
        private int cornerRadius;
        private Color bgColor;

        public RoundedPanel(int radius, Color bgColor) {
            super();
            this.cornerRadius = radius;
            this.bgColor = bgColor;
            setOpaque(false); // Quan trọng để hiển thị viền bo tròn chính xác
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); // Khử răng cưa

            // Vẽ lớp bóng đổ (Shadow) mờ ở dưới
            g2.setColor(new Color(0, 0, 0, 15));
            g2.fillRoundRect(3, 3, getWidth() - 6, getHeight() - 6, cornerRadius, cornerRadius);

            // Vẽ nền thẻ màu trắng ở trên
            g2.setColor(bgColor);
            g2.fillRoundRect(0, 0, getWidth() - 4, getHeight() - 4, cornerRadius, cornerRadius);
            g2.dispose();
        }
    }
}