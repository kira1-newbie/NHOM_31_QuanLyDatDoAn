package GUI;

import SCHEMA.NguoiDung;

import java.awt.*;
import java.awt.event.*;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import javax.swing.border.*;

public class FrmMain extends JFrame implements ActionListener {

    // Biến static để form frmDANGNHAP có thể gọi ngược lại cập nhật trạng thái
    public static FrmMain instance;

    // ── Màu sắc chủ đạo ───────────────────────────────────────────
    private static final Color BG_DARK = new Color(245, 245, 245);
    private static final Color BG_SURFACE = new Color(255, 255, 255);
    private static final Color COLOR_PRIMARY = new Color(238, 77, 45);
    private static final Color TEXT_MAIN = new Color(50, 50, 50);
    private static final Color TEXT_MUTED = new Color(130, 130, 130);
    private static final Color COLOR_GREEN = new Color(16, 185, 129);
    private static final Color BORDER_COLOR = new Color(230, 230, 230);

    // ── Menu & menu items ─────────────────────────────────────────────────────
    private JMenuBar menubar;
    private JMenu menuHeThong, menuKhachHang, menuDoiTac;
    private JMenuItem miDangNhap, miDangXuat, miDangKy;
    private JMenuItem miThucDon, miGioHang, miDonHangCuaToi;
    private JMenuItem miQuanLyQuan, miQuanLyDon, miThongKe, miCungShipper, miAdmin;

    // ── Desktop ───────────────────────────────────────────────────────────────
    public JDesktopPane theDesktop;

    // ── Sidebar buttons ───────────────────────────────────────────────────────
    private JButton btnThucDon, btnGioHang, btnDonHangCuaToi;
    private JButton btnQuanLyQuan, btnQuanLyDon, btnThongKe, btnShipper, btnAdmin;
    private JButton btnDangNhap, btnDangXuat;

    // ── Status bar components ─────────────────────────────────────────────────
    private JLabel lblClock;
    private JLabel lblUserStatus;
    private Timer clockTimer;

    // ── Trạng thái đăng nhập ─────────────────────────────────────────────────
    private boolean isLoggedIn = false;
    private NguoiDung currentUser = null;

    public FrmMain() {
        instance = this; // Gán instance

        setTitle("FoodApp PC - Hệ Thống Quản Lý Đặt Đồ Ăn");
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(BG_DARK);
        setLayout(new BorderLayout());

        buildMenuBar();

        // Tách màn hình: Trái là Sidebar, Phải là Desktop
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, buildSidebar(), buildDesktop());
        split.setDividerLocation(240);
        split.setDividerSize(1);
        split.setBorder(null);
        add(split, BorderLayout.CENTER);

        add(buildStatusBar(), BorderLayout.SOUTH);
        startClock();

        // Trạng thái ban đầu: chưa đăng nhập
        updateLoginState(false, null);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  ĐĂNG NHẬP — Gọi khi đăng nhập thành công
    // ─────────────────────────────────────────────────────────────────────────
    public void updateLoginState(boolean loggedIn, NguoiDung user) {
        isLoggedIn = loggedIn;
        currentUser = user;

        if (loggedIn && user != null) {
            String tenRole = "Không xác định";
            switch (user.getRoleId()) {
                case 1: tenRole = "ADMIN"; break;
                case 2: tenRole = "CUSTOMER"; break;
                case 3: tenRole = "SHIPPER"; break;
                case 4: tenRole = "RESTAURANT"; break;
            }

            lblUserStatus.setText("👤 " + user.getHoTen() + " (" + tenRole + ")");
            lblUserStatus.setForeground(COLOR_PRIMARY);
            phanQuyenGiaoDien(user.getRoleId());
        } else {
            lblUserStatus.setText("👤 Khách (Chưa đăng nhập)");
            lblUserStatus.setForeground(TEXT_MUTED);
            phanQuyenGiaoDien(0);
        }

        miDangNhap.setEnabled(!loggedIn);
        miDangKy.setEnabled(!loggedIn);
        miDangXuat.setEnabled(loggedIn);
        btnDangNhap.setEnabled(!loggedIn);
        btnDangXuat.setEnabled(loggedIn);
    }

    private void phanQuyenGiaoDien(int roleId) {
        boolean isCustomer = (roleId == 2);
        boolean isShipper = (roleId == 3);
        boolean isRestaurant = (roleId == 4);
        boolean isAdmin = (roleId == 1);

        // Khách Hàng
        btnThucDon.setEnabled(isCustomer);
        btnGioHang.setEnabled(isCustomer);
        btnDonHangCuaToi.setEnabled(isCustomer);
        miThucDon.setEnabled(isCustomer);
        miGioHang.setEnabled(isCustomer);
        miDonHangCuaToi.setEnabled(isCustomer);

        // Đối tác & Admin
        boolean hasRestaurantAccess = isRestaurant || isAdmin;
        btnQuanLyQuan.setEnabled(hasRestaurantAccess);
        btnQuanLyDon.setEnabled(hasRestaurantAccess);
        btnThongKe.setEnabled(hasRestaurantAccess);
        miQuanLyQuan.setEnabled(hasRestaurantAccess);
        miQuanLyDon.setEnabled(hasRestaurantAccess);
        miThongKe.setEnabled(hasRestaurantAccess);

        btnShipper.setEnabled(isShipper || isAdmin);
        miCungShipper.setEnabled(isShipper || isAdmin);

        btnAdmin.setEnabled(isAdmin);
        miAdmin.setEnabled(isAdmin);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  MENU BAR
    // ─────────────────────────────────────────────────────────────────────────
    private void buildMenuBar() {
        menubar = new JMenuBar();
        menubar.setBackground(BG_SURFACE);
        menubar.setBorder(new MatteBorder(0, 0, 1, 0, BORDER_COLOR));
        menubar.setPreferredSize(new Dimension(0, 45));

        JLabel logo = new JLabel("  🍜  FoodApp PC  ");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        logo.setForeground(COLOR_PRIMARY);
        menubar.add(logo);
        menubar.add(Box.createHorizontalStrut(16));

        // ── Hệ thống ──
        menuHeThong = makeMenu("Hệ thống");
        miDangNhap = makeItem("🔑  Đăng nhập", "dangnhap");
        miDangKy = makeItem("📝  Đăng ký", "dangky");
        miDangXuat = makeItem("🚪  Đăng xuất", "dangxuat");
        menuHeThong.add(miDangNhap);
        menuHeThong.add(miDangKy);
        menuHeThong.addSeparator();
        menuHeThong.add(miDangXuat);

        // ── Khách Hàng ──
        menuKhachHang = makeMenu("Khách hàng");
        miThucDon = makeItem("🍲  Thực đơn", "thucdon");
        miGioHang = makeItem("🛒  Giỏ hàng", "giohang");
        miDonHangCuaToi = makeItem("📋  Lịch sử đơn", "donhang");
        menuKhachHang.add(miThucDon);
        menuKhachHang.add(miGioHang);
        menuKhachHang.add(miDonHangCuaToi);

        // ── Đối Tác ──
        menuDoiTac = makeMenu("Đối tác & Quản trị");
        miQuanLyQuan = makeItem("🏪  Thực đơn Quán", "quanlyquan");
        miQuanLyDon = makeItem("📝  Đơn hàng Quán", "quanlydon");
        miThongKe = makeItem("📊  Thống kê Doanh thu", "thongke");
        miCungShipper = makeItem("🛵  Cổng Shipper", "shipper");
        miAdmin = makeItem("🛡️  Admin Panel", "admin");

        menuDoiTac.add(miQuanLyQuan);
        menuDoiTac.add(miQuanLyDon);
        menuDoiTac.add(miThongKe);
        menuDoiTac.addSeparator();
        menuDoiTac.add(miCungShipper);
        menuDoiTac.addSeparator();
        menuDoiTac.add(miAdmin);

        menubar.add(menuHeThong);
        menubar.add(menuKhachHang);
        menubar.add(menuDoiTac);
        menubar.add(Box.createHorizontalGlue());
        setJMenuBar(menubar);
    }

    private JMenu makeMenu(String text) {
        JMenu m = new JMenu(text);
        m.setFont(new Font("Segoe UI", Font.BOLD, 13));
        m.setForeground(TEXT_MAIN);
        return m;
    }

    private JMenuItem makeItem(String text, String cmd) {
        JMenuItem mi = new JMenuItem(text);
        mi.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        mi.setBackground(BG_SURFACE);
        mi.setBorder(new EmptyBorder(8, 15, 8, 20));
        mi.setActionCommand(cmd);
        mi.addActionListener(this);
        return mi;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  SIDEBAR
    // ─────────────────────────────────────────────────────────────────────────
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(BG_SURFACE);
        sidebar.setBorder(new CompoundBorder(
                new MatteBorder(0, 0, 0, 1, BORDER_COLOR),
                new EmptyBorder(20, 10, 20, 10)));
        sidebar.setPreferredSize(new Dimension(240, 0));

        // Nhóm Khách Hàng
        addLabel(sidebar, "KHÁCH HÀNG");
        btnThucDon = sideBtn("🍲  Thực đơn", "thucdon");
        btnGioHang = sideBtn("🛒  Giỏ hàng", "giohang");
        btnDonHangCuaToi = sideBtn("📋  Đơn hàng", "donhang");
        sidebar.add(btnThucDon); sidebar.add(vgap(5));
        sidebar.add(btnGioHang); sidebar.add(vgap(5));
        sidebar.add(btnDonHangCuaToi); sidebar.add(vgap(20));

        // Nhóm Đối Tác
        addLabel(sidebar, "QUÁN ĂN & ĐỐI TÁC");
        btnQuanLyQuan = sideBtn("🏪  Thực đơn Quán", "quanlyquan");
        btnQuanLyDon = sideBtn("📝  Đơn hàng Quán", "quanlydon");
        btnThongKe = sideBtn("📊  Thống kê", "thongke");
        btnShipper = sideBtn("🛵  Cổng Shipper", "shipper");
        btnAdmin = sideBtn("🛡️  Admin Dashboard", "admin");

        sidebar.add(btnQuanLyQuan); sidebar.add(vgap(5));
        sidebar.add(btnQuanLyDon); sidebar.add(vgap(5));
        sidebar.add(btnThongKe); sidebar.add(vgap(5));
        sidebar.add(btnShipper); sidebar.add(vgap(5));
        sidebar.add(btnAdmin); sidebar.add(vgap(20));

        // Nhóm Hệ Thống
        addLabel(sidebar, "HỆ THỐNG");
        btnDangNhap = sideBtn("🔑  Đăng nhập", "dangnhap");
        btnDangXuat = sideBtn("🚪  Đăng xuất", "dangxuat");
        sidebar.add(btnDangNhap); sidebar.add(vgap(5));
        sidebar.add(btnDangXuat);

        sidebar.add(Box.createVerticalGlue());

        // Thêm thanh cuộn cho Sidebar phòng trường hợp màn hình nhỏ
        JScrollPane scrollSidebar = new JScrollPane(sidebar);
        scrollSidebar.setBorder(null);
        scrollSidebar.getVerticalScrollBar().setUnitIncrement(16);

        JPanel pnlWrapper = new JPanel(new BorderLayout());
        pnlWrapper.add(scrollSidebar, BorderLayout.CENTER);
        return pnlWrapper;
    }

    private void addLabel(JPanel p, String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 11));
        l.setForeground(TEXT_MUTED);
        l.setBorder(new EmptyBorder(0, 10, 8, 0));
        p.add(l);
    }

    private Component vgap(int h) { return Box.createVerticalStrut(h); }

    private JButton sideBtn(String label, String cmd) {
        JButton btn = new JButton(label) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isRollover() && isEnabled()) {
                    g2.setColor(new Color(COLOR_PRIMARY.getRed(), COLOR_PRIMARY.getGreen(), COLOR_PRIMARY.getBlue(), 30));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                    g2.setColor(COLOR_PRIMARY);
                    g2.fillRoundRect(0, 8, 4, getHeight() - 16, 4, 4);
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setForeground(TEXT_MAIN);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setBorder(new EmptyBorder(12, 15, 12, 15));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 45));
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setActionCommand(cmd);
        btn.addActionListener(this);
        return btn;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  DESKTOP (Chính giữa)
    // ─────────────────────────────────────────────────────────────────────────
    private JPanel buildDesktop() {
        theDesktop = new JDesktopPane() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(230, 230, 230));
                g2.setFont(new Font("Segoe UI", Font.BOLD, 60));
                FontMetrics fm = g2.getFontMetrics();
                String text = "🍜 FoodApp PC";
                int x = (getWidth() - fm.stringWidth(text)) / 2;
                int y = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
                g2.drawString(text, x, y);
            }
        };
        theDesktop.setBackground(BG_DARK);

        JPanel w = new JPanel(new BorderLayout());
        w.add(theDesktop, BorderLayout.CENTER);
        return w;
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  STATUS BAR
    // ─────────────────────────────────────────────────────────────────────────
    private JPanel buildStatusBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        bar.setPreferredSize(new Dimension(0, 30));
        bar.setBackground(BG_SURFACE);
        bar.setBorder(new MatteBorder(1, 0, 0, 0, BORDER_COLOR));

        JLabel dot = new JLabel("●");
        dot.setForeground(COLOR_GREEN);
        new Timer(800, e -> dot.setVisible(!dot.isVisible())).start();

        JLabel lblKetNoi = new JLabel("Hệ thống Online");
        lblKetNoi.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        lblClock = new JLabel("--:--:--");
        lblClock.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblClock.setForeground(COLOR_PRIMARY);

        lblUserStatus = new JLabel("👤 Khách (Chưa đăng nhập)");
        lblUserStatus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblUserStatus.setForeground(TEXT_MUTED);

        bar.add(dot);
        bar.add(lblKetNoi);
        bar.add(new JLabel(" | "));
        bar.add(lblClock);
        bar.add(new JLabel(" | "));
        bar.add(lblUserStatus);

        return bar;
    }

    private void startClock() {
        clockTimer = new Timer(1000, e -> lblClock.setText(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"))));
        clockTimer.start();
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  ĐIỀU HƯỚNG SỰ KIỆN (ROUTING)
    // ─────────────────────────────────────────────────────────────────────────
    @Override
    public void actionPerformed(ActionEvent evt) {
        String cmd = evt.getActionCommand();

        switch (cmd) {
            case "dangnhap":
                new frmDANGNHAP().setVisible(true);
                break;
            case "dangky":
                new FrmDangKy().setVisible(true);
                break;
            case "dangxuat":
                int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn đăng xuất?", "Xác nhận", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    updateLoginState(false, null);
                    JOptionPane.showMessageDialog(this, "Đã đăng xuất thành công.");
                }
                break;
            case "thucdon":
                new FrmThucDon(currentUser).setVisible(true);
                break;
            case "giohang":
                new FrmGioHang(currentUser).setVisible(true);
                break;
            case "donhang":
                new FrmDonHangCuaToi(currentUser).setVisible(true);
                break;
            case "quanlyquan":
                new FrmQuanLyQuan(currentUser).setVisible(true);
                break;
            case "quanlydon":
                new FrmQuanLyDonHang(currentUser).setVisible(true);
                break;
            case "thongke":
                new FrmThongKe(currentUser).setVisible(true);
                break;
            case "shipper":
                new FrmShipper(currentUser).setVisible(true);
                break;
            case "admin":
                new FrmAdmin().setVisible(true);
                break;
            default:
                break;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  HÀM MAIN — KHỞI CHẠY ỨNG DỤNG
    // ─────────────────────────────────────────────────────────────────────────
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            System.err.println("Lỗi thiết lập giao diện: " + ex.getMessage());
        }

        SwingUtilities.invokeLater(() -> {
            new FrmMain().setVisible(true);
        });
    }
}