package GUI;

import BusinessLogic.NguoiDungBLL;
import SCHEMA.NguoiDung;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

public class frmDANGNHAP extends JFrame {

    // --- CÁC THÀNH PHẦN GIAO DIỆN ---
    private CustomTextField txtEmail;
    private CustomPasswordField txtMatKhau;
    private JButton btnDangNhap;
    private JLabel lblError;
    private JCheckBox chkHienThiMatKhau;
    private JCheckBox chkGhiNho;
    private JLabel lblQuenMatKhau;

    // --- TẦNG NGHIỆP VỤ ---
    private NguoiDungBLL nguoiDungBLL = new NguoiDungBLL();

    // --- BẢNG MÀU CHUẨN ---
    private final Color COLOR_BG = new Color(245, 246, 250);     // #F5F6FA
    private final Color COLOR_PRIMARY = new Color(230, 126, 34); // #E67E22
    private final Color COLOR_TEXT = new Color(44, 62, 80);      // #2C3E50

    public frmDANGNHAP() {
        initUI();
        addEvents();
        // Đã tắt hiệu ứng mờ dần để tránh lỗi IllegalComponentStateException
        // startFadeAnimation();
    }

    /**
     * 1. KHỞI TẠO VÀ SẮP XẾP GIAO DIỆN
     */
    private void initUI() {
        setTitle("Đăng Nhập - Hệ Thống Đặt Đồ Ăn");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Chỉ đóng form này, không tắt app
        setLocationRelativeTo(null);
        setResizable(false);

        // Panel nền chính
        JPanel pnlBackground = new JPanel(new GridBagLayout());
        pnlBackground.setBackground(COLOR_BG);

        // Panel chứa Form (Card Login bo góc)
        RoundedPanel pnlCard = new RoundedPanel(30, Color.WHITE);
        pnlCard.setPreferredSize(new Dimension(400, 420));
        pnlCard.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 20, 10, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Tiêu đề
        JLabel lblTitle = new JLabel("ĐĂNG NHẬP", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitle.setForeground(COLOR_PRIMARY);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        pnlCard.add(lblTitle, gbc);

        // Nhập Email
        txtEmail = new CustomTextField("Nhập Email của bạn...", 20);
        gbc.gridy = 1; gbc.insets = new Insets(20, 20, 5, 20);
        pnlCard.add(txtEmail, gbc);

        // Nhập Mật khẩu
        txtMatKhau = new CustomPasswordField("Nhập mật khẩu...", 20);
        gbc.gridy = 2; gbc.insets = new Insets(10, 20, 5, 20);
        pnlCard.add(txtMatKhau, gbc);

        // Sub-options: Hiển thị MK, Nhớ MK, Quên MK
        JPanel pnlOptions = new JPanel(new BorderLayout());
        pnlOptions.setOpaque(false);

        chkGhiNho = new JCheckBox("Nhớ tài khoản");
        chkGhiNho.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        chkGhiNho.setOpaque(false);
        chkGhiNho.setForeground(COLOR_TEXT);

        chkHienThiMatKhau = new JCheckBox("Hiện mật khẩu");
        chkHienThiMatKhau.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        chkHienThiMatKhau.setOpaque(false);
        chkHienThiMatKhau.setForeground(COLOR_TEXT);

        JPanel pnlChecks = new JPanel(new GridLayout(2, 1));
        pnlChecks.setOpaque(false);
        pnlChecks.add(chkGhiNho);
        pnlChecks.add(chkHienThiMatKhau);

        lblQuenMatKhau = new JLabel("Quên mật khẩu?");
        lblQuenMatKhau.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        lblQuenMatKhau.setForeground(new Color(41, 128, 185));
        lblQuenMatKhau.setCursor(new Cursor(Cursor.HAND_CURSOR));

        pnlOptions.add(pnlChecks, BorderLayout.WEST);
        pnlOptions.add(lblQuenMatKhau, BorderLayout.EAST);

        gbc.gridy = 3; gbc.insets = new Insets(0, 20, 5, 20);
        pnlCard.add(pnlOptions, gbc);

        // Label hiển thị lỗi Inline
        lblError = new JLabel(" ");
        lblError.setForeground(Color.RED);
        lblError.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblError.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridy = 4; gbc.insets = new Insets(0, 20, 5, 20);
        pnlCard.add(lblError, gbc);

        // Nút Đăng Nhập
        btnDangNhap = new JButton("ĐĂNG NHẬP");
        btnDangNhap.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnDangNhap.setForeground(Color.WHITE);
        btnDangNhap.setBackground(COLOR_PRIMARY);
        btnDangNhap.setFocusPainted(false);
        btnDangNhap.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnDangNhap.setPreferredSize(new Dimension(300, 45));
        btnDangNhap.setBorder(BorderFactory.createEmptyBorder());

        gbc.gridy = 5; gbc.insets = new Insets(5, 20, 20, 20);
        pnlCard.add(btnDangNhap, gbc);

        pnlBackground.add(pnlCard);
        add(pnlBackground);
    }

    /**
     * 2. GẮN CÁC SỰ KIỆN (EVENTS)
     */
    private void addEvents() {
        btnDangNhap.addActionListener(e -> xuLyDangNhap());

        // UX: Nhấn Enter ở ô mật khẩu sẽ submit luôn
        txtMatKhau.addActionListener(e -> xuLyDangNhap());
        txtEmail.addActionListener(e -> txtMatKhau.requestFocus());

        chkHienThiMatKhau.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                txtMatKhau.setEchoChar((char) 0);
            } else {
                txtMatKhau.setEchoChar('•');
            }
        });

        // Hover effect cho Button
        btnDangNhap.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if(btnDangNhap.isEnabled()) btnDangNhap.setBackground(COLOR_PRIMARY.darker());
            }
            @Override
            public void mouseExited(MouseEvent e) {
                if(btnDangNhap.isEnabled()) btnDangNhap.setBackground(COLOR_PRIMARY);
            }
        });
    }

    /**
     * 3. KIỂM TRA ĐẦU VÀO (VALIDATION)
     */
    private boolean validateInput() {
        String email = txtEmail.getText().trim();
        String password = new String(txtMatKhau.getPassword());

        if (email.isEmpty() || email.equals("Nhập Email của bạn...")) {
            lblError.setText("Vui lòng nhập Email!");
            txtEmail.requestFocus();
            return false;
        }
        if (password.isEmpty() || password.equals("Nhập mật khẩu...")) {
            lblError.setText("Vui lòng nhập Mật khẩu!");
            txtMatKhau.requestFocus();
            return false;
        }

        lblError.setText(" ");
        return true;
    }

    /**
     * 4. XỬ LÝ ĐĂNG NHẬP (BẤT ĐỒNG BỘ VỚI SWINGWORKER)
     */
    private void xuLyDangNhap() {
        if (!validateInput()) return;

        String email = txtEmail.getText().trim();
        String password = new String(txtMatKhau.getPassword());

        btnDangNhap.setEnabled(false);
        btnDangNhap.setText("Đang xử lý...");
        btnDangNhap.setBackground(Color.GRAY);

        SwingWorker<NguoiDung, Void> worker = new SwingWorker<NguoiDung, Void>() {
            @Override
            protected NguoiDung doInBackground() {
                try { Thread.sleep(500); } catch (Exception ignored) {}
                return nguoiDungBLL.dangNhap(email, password);
            }

            @Override
            protected void done() {
                btnDangNhap.setEnabled(true);
                btnDangNhap.setText("ĐĂNG NHẬP");
                btnDangNhap.setBackground(COLOR_PRIMARY);

                try {
                    NguoiDung user = get();
                    if (user != null) {
                        dieuHuongTheoRole(user);
                    } else {
                        lblError.setText("Sai Email hoặc Mật khẩu!");
                    }
                } catch (Exception ex) {
                    lblError.setText("Lỗi kết nối hệ thống!");
                    ex.printStackTrace();
                }
            }
        };
        worker.execute();
    }

    /**
     * 5. ROUTING: ĐIỀU HƯỚNG MÀN HÌNH THEO ROLE
     */
    private void dieuHuongTheoRole(NguoiDung user) {
        // Cập nhật trạng thái cho form Main
        if (FrmMain.instance != null) {
            FrmMain.instance.updateLoginState(true, user);
        }

        switch (user.getRoleId()) {
            case 1:
                JOptionPane.showMessageDialog(this, "Chào mừng ADMIN đăng nhập thành công!");
                break;
            case 2:
                JOptionPane.showMessageDialog(this, "Chào mừng CUSTOMER! Mời bạn chọn món.");
                break;
            case 3:
                JOptionPane.showMessageDialog(this, "Chào mừng SHIPPER! Hãy kiểm tra đơn hàng.");
                break;
            case 4:
                JOptionPane.showMessageDialog(this, "Chào mừng QUÁN ĂN! Hệ thống đã sẵn sàng.");
                break;
        }

        this.dispose(); // Đóng form đăng nhập sau khi xử lý xong
    }

    // ==========================================================
    // CÁC LỚP UI TIỆN ÍCH (INNER CLASSES)
    // ==========================================================

    class RoundedPanel extends JPanel {
        private int cornerRadius;
        private Color bgColor;

        public RoundedPanel(int radius, Color bgColor) {
            super();
            this.cornerRadius = radius;
            this.bgColor = bgColor;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(new Color(0, 0, 0, 20));
            g2.fillRoundRect(3, 3, getWidth() - 6, getHeight() - 6, cornerRadius, cornerRadius);

            g2.setColor(bgColor);
            g2.fillRoundRect(0, 0, getWidth() - 4, getHeight() - 4, cornerRadius, cornerRadius);
            g2.dispose();
        }
    }

    class CustomTextField extends JTextField {
        private String placeholder;

        public CustomTextField(String placeholder, int columns) {
            super(columns);
            this.placeholder = placeholder;
            setFont(new Font("Segoe UI", Font.PLAIN, 14));
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                    new EmptyBorder(8, 10, 8, 10)
            ));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (getText().isEmpty() && !hasFocus()) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.GRAY);
                g2.setFont(getFont().deriveFont(Font.ITALIC));
                int x = getInsets().left;
                int y = (getHeight() - g.getFontMetrics().getHeight()) / 2 + g.getFontMetrics().getAscent();
                g2.drawString(placeholder, x, y);
                g2.dispose();
            }
        }
    }

    class CustomPasswordField extends JPasswordField {
        private String placeholder;

        public CustomPasswordField(String placeholder, int columns) {
            super(columns);
            this.placeholder = placeholder;
            setFont(new Font("Segoe UI", Font.PLAIN, 14));
            setEchoChar('•');
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                    new EmptyBorder(8, 10, 8, 10)
            ));
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (new String(getPassword()).isEmpty() && !hasFocus()) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.GRAY);
                g2.setFont(getFont().deriveFont(Font.ITALIC));
                int x = getInsets().left;
                int y = (getHeight() - g.getFontMetrics().getHeight()) / 2 + g.getFontMetrics().getAscent();
                g2.drawString(placeholder, x, y);
                g2.dispose();
            }
        }
    }
}