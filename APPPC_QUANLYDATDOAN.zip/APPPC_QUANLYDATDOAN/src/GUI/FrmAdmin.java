package GUI;

import BusinessLogic.NguoiDungBLL;
import SCHEMA.NguoiDung;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class FrmAdmin extends JFrame {

    private NguoiDungBLL nguoiDungBLL = new NguoiDungBLL();

    // Các thành phần UI
    private JTable tableUsers;
    private DefaultTableModel tableModel;
    private JButton btnDoiTrangThai;
    private JButton btnLamMoi;

    private final Color COLOR_PRIMARY = new Color(238, 77, 45); // Cam FoodApp

    public FrmAdmin() {
        initUI();
        loadData();
    }

    /**
     * 1. Khởi tạo giao diện
     */
    private void initUI() {
        setTitle("Admin Dashboard - Quản Lý Hệ Thống");
        setSize(900, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(Color.WHITE);

        // --- Header ---
        JPanel pnlHeader = new JPanel(new BorderLayout());
        pnlHeader.setBackground(Color.WHITE);
        pnlHeader.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel lblTitle = new JLabel("🛡️ Quản Lý Người Dùng");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(COLOR_PRIMARY);
        pnlHeader.add(lblTitle, BorderLayout.WEST);

        btnLamMoi = new JButton("🔄 Làm Mới");
        btnLamMoi.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLamMoi.setBackground(Color.WHITE);
        btnLamMoi.setForeground(COLOR_PRIMARY);
        btnLamMoi.setFocusPainted(false);
        btnLamMoi.addActionListener(e -> loadData());
        pnlHeader.add(btnLamMoi, BorderLayout.EAST);

        add(pnlHeader, BorderLayout.NORTH);

        // --- Bảng dữ liệu ---
        String[] columns = {"Mã User", "Họ Tên", "Email", "Số Điện Thoại", "Vai Trò (Role)", "Trạng Thái"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tableUsers = new JTable(tableModel);
        tableUsers.setRowHeight(30);
        tableUsers.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tableUsers.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableUsers.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(tableUsers);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));
        add(scrollPane, BorderLayout.CENTER);

        // --- Bottom (Nút chức năng) ---
        JPanel pnlBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pnlBottom.setBorder(new EmptyBorder(10, 20, 20, 20));
        pnlBottom.setBackground(Color.WHITE);

        btnDoiTrangThai = new JButton("KHÓA / MỞ KHÓA TÀI KHOẢN");
        btnDoiTrangThai.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnDoiTrangThai.setBackground(COLOR_PRIMARY);
        btnDoiTrangThai.setForeground(Color.WHITE);
        btnDoiTrangThai.setPreferredSize(new Dimension(250, 40));
        btnDoiTrangThai.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnDoiTrangThai.addActionListener(e -> xuLyDoiTrangThai());

        pnlBottom.add(btnDoiTrangThai);
        add(pnlBottom, BorderLayout.SOUTH);
    }

    /**
     * 2. Tải dữ liệu lên bảng
     */
    private void loadData() {
        tableModel.setRowCount(0);
        java.util.List<NguoiDung> danhSach = nguoiDungBLL.layDanhSachTaiKhoan();

        for (NguoiDung nd : danhSach) {
            // Chuyển RoleId thành chuỗi dễ đọc
            String tenRole = "Không xác định";
            switch (nd.getRoleId()) {
                case 1: tenRole = "ADMIN"; break;
                case 2: tenRole = "CUSTOMER"; break;
                case 3: tenRole = "SHIPPER"; break;
                case 4: tenRole = "RESTAURANT"; break;
            }

            tableModel.addRow(new Object[]{
                    nd.getNguoiDungId(),
                    nd.getHoTen(),
                    nd.getEmail(),
                    nd.getSoDienThoai(),
                    tenRole,
                    nd.getTrangThai()
            });
        }
    }

    /**
     * 3. Xử lý đổi trạng thái tài khoản
     */
    private void xuLyDoiTrangThai() {
        int row = tableUsers.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một người dùng trên bảng!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String userId = tableModel.getValueAt(row, 0).toString();
        String trangThaiHienTai = tableModel.getValueAt(row, 5).toString();
        String role = tableModel.getValueAt(row, 4).toString();

        if (role.equals("ADMIN")) {
            JOptionPane.showMessageDialog(this, "Bạn không thể khóa tài khoản ADMIN!", "Cảnh báo", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "Bạn muốn đổi trạng thái của tài khoản " + userId + "?\nTrạng thái hiện tại: " + trangThaiHienTai,
                "Xác nhận", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (nguoiDungBLL.daoNguocTrangThai(userId, trangThaiHienTai)) {
                JOptionPane.showMessageDialog(this, "Đã cập nhật trạng thái tài khoản thành công!");
                loadData(); // Cập nhật lại bảng
            } else {
                JOptionPane.showMessageDialog(this, "Có lỗi xảy ra, vui lòng thử lại.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}