package GUI;

import BusinessLogic.DonHangBLL;
import SCHEMA.NguoiDung;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.text.DecimalFormat;

public class FrmThongKe extends JFrame {

    private NguoiDung currentUser;
    private DonHangBLL donHangBLL = new DonHangBLL();
    private JFrame parentFrame;

    public void setParentFrame(JFrame parent) {
        this.parentFrame = parent;
    }

    // UI Components
    private JLabel lblTongDon;
    private JLabel lblDoanhThu;

    // --- Dark Theme Palette (Rose) ---
    private final Color COLOR_BG = new Color(15, 23, 42);
    private final Color COLOR_CARD = new Color(30, 41, 59);
    private final Color COLOR_PRIMARY = new Color(244, 63, 94);
    private final Color COLOR_TEXT = Color.WHITE;

    public FrmThongKe(NguoiDung user) {
        this.currentUser = user;
        initUI();
        loadData();
    }

    private void initUI() {
        setTitle("Thống Kê Doanh Thu");
        setSize(850, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                if (parentFrame != null) {
                    parentFrame.setVisible(true);
                }
            }
        });
        setLayout(new BorderLayout());
        getContentPane().setBackground(COLOR_BG);

        // --- Header ---
        JPanel pnlTop = new JPanel(new BorderLayout());
        pnlTop.setBackground(COLOR_BG);

        JPanel pnlHeader = new JPanel(new BorderLayout());
        pnlHeader.setBackground(COLOR_BG);
        pnlHeader.setBorder(new EmptyBorder(15, 20, 10, 20));

        JLabel lblTitle = new JLabel("BÁO CÁO KẾT QUẢ KINH DOANH");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(COLOR_PRIMARY);
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        pnlHeader.add(lblTitle, BorderLayout.CENTER);
        pnlTop.add(pnlHeader, BorderLayout.NORTH);

        JPanel pnlNavBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 5));
        pnlNavBar.setBackground(COLOR_BG);

        JButton btnTabThucDon = createNavButton("Thực Đơn Quán", false);
        JButton btnTabDonHang = createNavButton("Đơn Hàng Quán", false);
        JButton btnTabThongKe = createNavButton("Thống Kê", true);

        btnTabThucDon.addActionListener(e -> {
            FrmQuanLyQuan frm = new FrmQuanLyQuan(currentUser);
            if (this.parentFrame != null) {
                frm.setParentFrame(this.parentFrame);
                this.parentFrame = null;
            }
            frm.setVisible(true);
            this.dispose();
        });
        btnTabDonHang.addActionListener(e -> {
            FrmQuanLyDonHang frm = new FrmQuanLyDonHang(currentUser);
            if (this.parentFrame != null) {
                frm.setParentFrame(this.parentFrame);
                this.parentFrame = null;
            }
            frm.setVisible(true);
            this.dispose();
        });

        pnlNavBar.add(btnTabThucDon);
        pnlNavBar.add(btnTabDonHang);
        pnlNavBar.add(btnTabThongKe);

        pnlTop.add(pnlNavBar, BorderLayout.SOUTH);
        add(pnlTop, BorderLayout.NORTH);

        // --- Center (Các thẻ thống kê) ---
        JPanel pnlCenter = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 50));
        pnlCenter.setBackground(COLOR_BG);

        // Thẻ 1: Tổng số đơn hàng
        GradientRoundedPanel pnlDonHang = createStatCard("TỔNG SỐ ĐƠN HÀNG", new Color(14, 165, 233), new Color(2, 132, 199), "/icons/box.png");
        lblTongDon = new JLabel("0 Đơn");
        lblTongDon.setFont(new Font("Segoe UI", Font.BOLD, 36));
        lblTongDon.setForeground(Color.WHITE);
        lblTongDon.setHorizontalAlignment(SwingConstants.CENTER);
        pnlDonHang.add(lblTongDon, BorderLayout.CENTER);
        pnlCenter.add(pnlDonHang);

        // Thẻ 2: Tổng doanh thu
        GradientRoundedPanel pnlDoanhThu = createStatCard("TỔNG DOANH THU", new Color(34, 197, 94), new Color(21, 128, 61), "/icons/money.png");
        lblDoanhThu = new JLabel("0 VNĐ");
        lblDoanhThu.setFont(new Font("Segoe UI", Font.BOLD, 32));
        lblDoanhThu.setForeground(Color.WHITE);
        lblDoanhThu.setHorizontalAlignment(SwingConstants.CENTER);
        pnlDoanhThu.add(lblDoanhThu, BorderLayout.CENTER);
        pnlCenter.add(pnlDoanhThu);

        add(pnlCenter, BorderLayout.CENTER);

        // --- Bottom ---
        JPanel pnlBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pnlBottom.setBackground(COLOR_BG);
        pnlBottom.setBorder(new EmptyBorder(10, 20, 20, 20));
        JButton btnDong = new JButton("ĐÓNG");
        btnDong.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnDong.setBackground(COLOR_PRIMARY);
        btnDong.setForeground(Color.WHITE);
        btnDong.setContentAreaFilled(false);
        btnDong.setFocusPainted(false);
        btnDong.setOpaque(true);
        btnDong.setBorder(BorderFactory.createLineBorder(COLOR_PRIMARY, 1));
        btnDong.setPreferredSize(new Dimension(100, 40));
        btnDong.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnDong.addActionListener(e -> this.dispose());
        pnlBottom.add(btnDong);

        JPanel pnlFooterWrapper = new JPanel(new BorderLayout());
        pnlFooterWrapper.setBackground(COLOR_BG);

        JPanel pnlUserInfo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlUserInfo.setBackground(COLOR_BG);
        JLabel lblUser = new JLabel("Chủ quán: " + currentUser.getHoTen());
        lblUser.setForeground(Color.LIGHT_GRAY);
        pnlUserInfo.add(lblUser);

        pnlFooterWrapper.add(pnlBottom, BorderLayout.CENTER);
        pnlFooterWrapper.add(pnlUserInfo, BorderLayout.SOUTH);

        add(pnlFooterWrapper, BorderLayout.SOUTH);
    }

    /**
     * Hàm tiện ích tạo một thẻ (Card) thống kê bo góc Gradient
     */
    private GradientRoundedPanel createStatCard(String title, Color c1, Color c2, String iconPath) {
        GradientRoundedPanel card = new GradientRoundedPanel(25, c1, c2);
        card.setPreferredSize(new Dimension(350, 160));
        card.setLayout(new BorderLayout());
        card.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTitle.setForeground(new Color(255, 255, 255, 220));

        JLabel lblIcon = new JLabel();
        try {
            lblIcon.setIcon(new ImageIcon(getClass().getResource(iconPath)));
        } catch(Exception e) {
            lblIcon.setIcon(new ImageIcon("src" + iconPath));
        }

        JPanel pnlTop = new JPanel(new BorderLayout());
        pnlTop.setOpaque(false);
        pnlTop.add(lblTitle, BorderLayout.WEST);
        pnlTop.add(lblIcon, BorderLayout.EAST);

        card.add(pnlTop, BorderLayout.NORTH);

        return card;
    }

    private JButton createNavButton(String text, boolean isActive) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        if (isActive) {
            styleButton(btn, COLOR_PRIMARY, COLOR_PRIMARY, new Dimension(150, 38));
        } else {
            styleButton(btn, COLOR_CARD, COLOR_PRIMARY, new Dimension(150, 38));
        }
        return btn;
    }

    private static void styleButton(JButton btn, Color bg, Color border, Dimension size) {
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createLineBorder(border, 1));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        if (size != null) btn.setPreferredSize(size);
    }

    /**
     * Nạp dữ liệu từ CSDL
     */
    private void loadData() {
        // Lấy đúng mã quán theo chủ quán (tránh tự ghép mã dễ sai)
        String quanAnId = new ProcessData.NguoiDungDAO().layQuanAnId(currentUser.getNguoiDungId());
        if (quanAnId == null || quanAnId.trim().isEmpty()) {
            lblTongDon.setText("0 Đơn");
            lblDoanhThu.setText("0 VNĐ");
            JOptionPane.showMessageDialog(this,
                    "Không tìm thấy quán ăn của tài khoản này.\nVui lòng kiểm tra dữ liệu bảng QuanAn (ChuQuanId).",
                    "Thiếu dữ liệu quán ăn",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        double[] ketQua = donHangBLL.layThongKeDoanhThu(quanAnId);

        // Hiển thị số đơn
        lblTongDon.setText((int)ketQua[0] + " Đơn");

        // Hiển thị doanh thu
        DecimalFormat df = new DecimalFormat("#,### VNĐ");
        lblDoanhThu.setText(df.format(ketQua[1]));
    }

    // --- Lớp Inner Class tạo Panel bo góc Gradient ---
    class GradientRoundedPanel extends JPanel {
        private int cornerRadius;
        private Color colorStart;
        private Color colorEnd;

        public GradientRoundedPanel(int radius, Color c1, Color c2) {
            super();
            this.cornerRadius = radius;
            this.colorStart = c1;
            this.colorEnd = c2;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            // Vẽ Shadow mềm mại
            g2.setColor(new Color(0, 0, 0, 50));
            g2.fillRoundRect(4, 4, getWidth() - 4, getHeight() - 4, cornerRadius, cornerRadius);

            // Vẽ nền Gradient
            GradientPaint gp = new GradientPaint(0, 0, colorStart, getWidth(), getHeight(), colorEnd);
            g2.setPaint(gp);
            g2.fillRoundRect(0, 0, getWidth() - 6, getHeight() - 6, cornerRadius, cornerRadius);
            g2.dispose();
        }
    }
}
