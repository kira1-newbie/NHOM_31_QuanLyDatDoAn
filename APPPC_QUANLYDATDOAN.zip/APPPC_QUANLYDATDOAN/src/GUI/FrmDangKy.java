package GUI;

import BusinessLogic.NguoiDungBLL;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class FrmDangKy extends JFrame {

    private NguoiDungBLL nguoiDungBLL = new NguoiDungBLL();

    // Các thành phần UI
    private JTextField txtHoTen, txtEmail, txtSDT;
    private JPasswordField txtMatKhau, txtXacNhanMK;
    private JButton btnDangKy, btnHuy;

    private final Color COLOR_PRIMARY = new Color(238, 77, 45);

    public FrmDangKy() {
        initUI();
    }

    private void initUI() {
        setTitle("Đăng Ký Tài Khoản Mới");
        setSize(450, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(new Color(245, 246, 250));

        // Panel chứa form nhập liệu
        JPanel pnlForm = new JPanel(new GridBagLayout());
        pnlForm.setBackground(Color.WHITE);
        pnlForm.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1, true),
                new EmptyBorder(20, 30, 20, 30)));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 0, 10, 0);
        gbc.weightx = 1.0;

        // Tiêu đề
        JLabel lblTitle = new JLabel("TẠO TÀI KHOẢN", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(COLOR_PRIMARY);
        gbc.gridy = 0;
        pnlForm.add(lblTitle, gbc);

        // Các trường nhập liệu
        txtHoTen = createTextField("Họ và tên");
        gbc.gridy = 1; pnlForm.add(txtHoTen, gbc);

        txtEmail = createTextField("Email");
        gbc.gridy = 2; pnlForm.add(txtEmail, gbc);

        txtSDT = createTextField("Số điện thoại");
        gbc.gridy = 3; pnlForm.add(txtSDT, gbc);

        txtMatKhau = createPasswordField("Mật khẩu");
        gbc.gridy = 4; pnlForm.add(txtMatKhau, gbc);

        txtXacNhanMK = createPasswordField("Xác nhận mật khẩu");
        gbc.gridy = 5; pnlForm.add(txtXacNhanMK, gbc);

        // Nút Đăng ký
        btnDangKy = new JButton("ĐĂNG KÝ");
        btnDangKy.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnDangKy.setBackground(COLOR_PRIMARY);
        btnDangKy.setForeground(Color.WHITE);
        btnDangKy.setPreferredSize(new Dimension(0, 45));
        btnDangKy.setFocusPainted(false);
        btnDangKy.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnDangKy.addActionListener(e -> xuLyDangKy());
        gbc.gridy = 6; gbc.insets = new Insets(20, 0, 5, 0);
        pnlForm.add(btnDangKy, gbc);

        // Nút Hủy
        btnHuy = new JButton("Hủy bỏ");
        btnHuy.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnHuy.setBackground(Color.WHITE);
        btnHuy.setForeground(Color.GRAY);
        btnHuy.setBorderPainted(false);
        btnHuy.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnHuy.addActionListener(e -> this.dispose());
        gbc.gridy = 7; gbc.insets = new Insets(0, 0, 10, 0);
        pnlForm.add(btnHuy, gbc);

        // Đưa form vào giữa màn hình
        setLayout(new GridBagLayout());
        add(pnlForm);
    }

    private JTextField createTextField(String placeholder) {
        JTextField txt = new JTextField();
        txt.setPreferredSize(new Dimension(300, 40));
        txt.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txt.setBorder(BorderFactory.createTitledBorder(placeholder));
        return txt;
    }

    private JPasswordField createPasswordField(String placeholder) {
        JPasswordField txt = new JPasswordField();
        txt.setPreferredSize(new Dimension(300, 40));
        txt.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txt.setBorder(BorderFactory.createTitledBorder(placeholder));
        return txt;
    }

    private void xuLyDangKy() {
        String hoTen = txtHoTen.getText().trim();
        String email = txtEmail.getText().trim();
        String sdt = txtSDT.getText().trim();
        String matKhau = new String(txtMatKhau.getPassword());
        String xacNhan = new String(txtXacNhanMK.getPassword());

        // Bỏ qua nếu rỗng
        if (hoTen.isEmpty() || email.isEmpty() || sdt.isEmpty() || matKhau.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Gọi BLL xử lý
        boolean thanhCong = nguoiDungBLL.dangKyKhachHang(hoTen, email, sdt, matKhau, xacNhan);

        if (thanhCong) {
            JOptionPane.showMessageDialog(this, "Đăng ký tài khoản thành công!\nBạn có thể đăng nhập ngay bây giờ.", "Thành công", JOptionPane.INFORMATION_MESSAGE);
            this.dispose(); // Đóng form đăng ký
        } else {
            JOptionPane.showMessageDialog(this, "Đăng ký thất bại. Vui lòng kiểm tra lại mật khẩu hoặc Email đã tồn tại.", "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }
}