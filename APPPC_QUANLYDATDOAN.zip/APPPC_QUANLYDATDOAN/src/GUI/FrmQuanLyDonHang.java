package GUI;

import BusinessLogic.DonHangBLL;
import SCHEMA.DonHang;
import SCHEMA.NguoiDung;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;

public class FrmQuanLyDonHang extends JFrame {

    private NguoiDung currentUser;
    private DonHangBLL donHangBLL = new DonHangBLL();

    private JTable tableDonHang;
    private DefaultTableModel tableModel;
    private JButton btnXacNhan, btnHuyDon, btnLamMoi;

    private final Color COLOR_PRIMARY = new Color(238, 77, 45);
    private final DecimalFormat dfMoney = new DecimalFormat("#,### VNĐ");
    private final SimpleDateFormat dfDate = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    public FrmQuanLyDonHang(NguoiDung user) {
        this.currentUser = user;
        initUI();
        loadData();
    }

    private void initUI() {
        setTitle("Quản Lý Đơn Hàng Dành Cho Quán Ăn");
        setSize(950, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // --- Header ---
        JPanel pnlHeader = new JPanel(new BorderLayout());
        pnlHeader.setBackground(Color.WHITE);
        pnlHeader.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel lblTitle = new JLabel("📝 Danh Sách Đơn Hàng");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(COLOR_PRIMARY);
        pnlHeader.add(lblTitle, BorderLayout.WEST);

        btnLamMoi = new JButton("🔄 Làm Mới");
        btnLamMoi.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLamMoi.setBackground(Color.WHITE);
        btnLamMoi.setForeground(COLOR_PRIMARY);
        btnLamMoi.setFocusPainted(false);
        btnLamMoi.addActionListener(e -> loadData());
        pnlHeader.add(btnLamMoi, BorderLayout.EAST);

        add(pnlHeader, BorderLayout.NORTH);

        // --- Table ---
        String[] columns = {"Mã Đơn", "Thời Gian", "Tổng Tiền", "Mã Khách", "Trạng Thái"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        tableDonHang = new JTable(tableModel);
        tableDonHang.setRowHeight(30);
        tableDonHang.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tableDonHang.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableDonHang.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(tableDonHang);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        add(scrollPane, BorderLayout.CENTER);

        // --- Bottom (Các nút thao tác) ---
        JPanel pnlBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        pnlBottom.setBorder(new EmptyBorder(10, 20, 20, 20));

        btnXacNhan = new JButton("XÁC NHẬN ĐƠN (CHUẨN BỊ MÓN)");
        btnXacNhan.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnXacNhan.setBackground(new Color(16, 185, 129)); // Màu xanh lá
        btnXacNhan.setForeground(Color.WHITE);
        btnXacNhan.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnHuyDon = new JButton("TỪ CHỐI ĐƠN HÀNG");
        btnHuyDon.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnHuyDon.setBackground(new Color(220, 38, 38)); // Màu đỏ
        btnHuyDon.setForeground(Color.WHITE);
        btnHuyDon.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnXacNhan.addActionListener(e -> capNhatTrangThai("ĐÃ XÁC NHẬN"));
        btnHuyDon.addActionListener(e -> capNhatTrangThai("ĐÃ HỦY"));

        pnlBottom.add(btnXacNhan);
        pnlBottom.add(btnHuyDon);
        add(pnlBottom, BorderLayout.SOUTH);
    }

    private void loadData() {
        tableModel.setRowCount(0);
        // Giả lập QuanAnId từ NguoiDungId (Chủ quán)
        String quanAnId = "QA" + currentUser.getNguoiDungId().substring(3);
        List<DonHang> danhSach = donHangBLL.layDanhSachDonHangQuanAn(quanAnId);

        for (DonHang dh : danhSach) {
            tableModel.addRow(new Object[]{
                    dh.getDonHangId(),
                    dfDate.format(dh.getThoiGianDat()),
                    dfMoney.format(dh.getTongTien()),
                    dh.getKhachHangId(),
                    dh.getTrangThai()
            });
        }
    }

    private void capNhatTrangThai(String trangThaiMoi) {
        int row = tableDonHang.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một đơn hàng!", "Thông báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String donHangId = tableModel.getValueAt(row, 0).toString();
        String trangThaiHienTai = tableModel.getValueAt(row, 4).toString();

        if (!trangThaiHienTai.equals("CHỜ XÁC NHẬN")) {
            JOptionPane.showMessageDialog(this, "Chỉ có thể thao tác với đơn hàng đang CHỜ XÁC NHẬN!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Chuyển đơn hàng " + donHangId + " sang trạng thái: " + trangThaiMoi + "?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (donHangBLL.capNhatTrangThai(donHangId, trangThaiMoi)) {
                JOptionPane.showMessageDialog(this, "Cập nhật thành công!");
                loadData();
            } else {
                JOptionPane.showMessageDialog(this, "Cập nhật thất bại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}