package GUI;

import BusinessLogic.DanhGiaBLL;
import BusinessLogic.DonHangBLL;
import SCHEMA.DonHang;
import SCHEMA.NguoiDung;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;

public class FrmDonHangCuaToi extends JFrame {
    private static final Dimension FRAME_SIZE = new Dimension(1200, 680);
    private static final Dimension BUTTON_SIZE_SMALL = new Dimension(120, 42);
    private static final Dimension BUTTON_SIZE_MEDIUM = new Dimension(155, 42);
    private static final Dimension BUTTON_SIZE_LARGE = new Dimension(170, 42);

    private static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 26);
    private static final Font FONT_TABLE = new Font("Segoe UI", Font.PLAIN, 15);
    private static final Font FONT_TABLE_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 14);

    private NguoiDung currentUser;
    private DonHangBLL donHangBLL = new DonHangBLL();
    private DanhGiaBLL danhGiaBLL = new DanhGiaBLL();

    private JTable tableDonHang;
    private DefaultTableModel tableModel;

    private final Color COLOR_BG = new Color(15, 23, 42);
    private final Color COLOR_CARD = new Color(30, 41, 59);
    private final Color COLOR_PRIMARY = new Color(249, 115, 22);
    private final Color COLOR_TEXT = Color.WHITE;

    private final DecimalFormat dfMoney = new DecimalFormat("#,### VNĐ");
    private final SimpleDateFormat dfDate = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    public FrmDonHangCuaToi(NguoiDung user) {
        this.currentUser = user;
        initUI();
        loadData();
    }

    private void initUI() {
        setTitle("Lịch Sử Đơn Hàng");
        setSize(FRAME_SIZE);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(COLOR_BG);

        JPanel pnlHeader = new JPanel();
        pnlHeader.setBackground(COLOR_BG);
        pnlHeader.setBorder(new EmptyBorder(15, 20, 15, 20));
        JLabel lblTitle = new JLabel("Đơn Hàng Của Tôi");
        lblTitle.setFont(FONT_TITLE);
        lblTitle.setForeground(COLOR_PRIMARY);
        pnlHeader.add(lblTitle);
        add(pnlHeader, BorderLayout.NORTH);

        // Cột "Mã Quán" được giữ trong model để lưu đánh giá đúng quán,
        // nhưng sẽ bị ẩn khỏi JTable vì khách hàng không cần thấy cột kỹ thuật này.
        String[] columns = {
                "Mã Đơn", "Thời Gian Đặt", "Tổng Tiền", "Trạng Thái",
                "Thanh Toán", "Đánh Giá", "Địa Chỉ Giao", "Mã Quán"
        };
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableDonHang = new JTable(tableModel);
        tableDonHang.setRowHeight(34);
        tableDonHang.setFont(FONT_TABLE);
        tableDonHang.setBackground(COLOR_CARD);
        tableDonHang.setForeground(COLOR_TEXT);
        tableDonHang.setGridColor(new Color(50, 50, 50));
        tableDonHang.setSelectionBackground(new Color(50, 80, 50));
        tableDonHang.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        javax.swing.table.DefaultTableCellRenderer headerRenderer = new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                c.setBackground(COLOR_PRIMARY);
                c.setForeground(Color.WHITE);
                c.setFont(FONT_TABLE_HEADER);
                return c;
            }
        };
        headerRenderer.setHorizontalAlignment(JLabel.CENTER);

        javax.swing.table.DefaultTableCellRenderer centerRenderer = new javax.swing.table.DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);

        for (int i = 0; i < tableDonHang.getColumnModel().getColumnCount(); i++) {
            tableDonHang.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
            if (i != 6) {
                tableDonHang.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            }
        }

        tableDonHang.getColumnModel().getColumn(0).setPreferredWidth(80);
        tableDonHang.getColumnModel().getColumn(1).setPreferredWidth(145);
        tableDonHang.getColumnModel().getColumn(2).setPreferredWidth(110);
        tableDonHang.getColumnModel().getColumn(3).setPreferredWidth(130);
        tableDonHang.getColumnModel().getColumn(4).setPreferredWidth(190);
        tableDonHang.getColumnModel().getColumn(5).setPreferredWidth(110);
        tableDonHang.getColumnModel().getColumn(6).setPreferredWidth(280);
        tableDonHang.removeColumn(tableDonHang.getColumnModel().getColumn(7));

        JScrollPane scrollPane = new JScrollPane(tableDonHang);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(50, 50, 50)));
        scrollPane.getViewport().setBackground(COLOR_BG);
        add(scrollPane, BorderLayout.CENTER);

        JPanel pnlBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        pnlBottom.setBackground(COLOR_BG);
        pnlBottom.setBorder(new EmptyBorder(10, 20, 20, 20));

        JButton btnDanhGia = new JButton("ĐÁNH GIÁ");
        btnDanhGia.setFont(FONT_BUTTON);
        styleButton(btnDanhGia, new Color(16, 185, 129), new Color(16, 185, 129), BUTTON_SIZE_MEDIUM);
        btnDanhGia.addActionListener(e -> xuLyDanhGia());

        JButton btnHuyDon = new JButton("HỦY ĐƠN HÀNG");
        btnHuyDon.setFont(FONT_BUTTON);
        styleButton(btnHuyDon, new Color(220, 53, 69), new Color(220, 53, 69), BUTTON_SIZE_LARGE);
        btnHuyDon.addActionListener(e -> xuLyHuyDon());

        JButton btnDong = new JButton("ĐÓNG");
        btnDong.setFont(FONT_BUTTON);
        styleButton(btnDong, COLOR_PRIMARY, COLOR_PRIMARY, BUTTON_SIZE_SMALL);
        btnDong.addActionListener(e -> this.dispose());

        pnlBottom.add(btnDanhGia);
        pnlBottom.add(btnHuyDon);
        pnlBottom.add(btnDong);

        JPanel pnlFooterWrapper = new JPanel(new BorderLayout());
        pnlFooterWrapper.setBackground(COLOR_BG);

        JPanel pnlUserInfo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlUserInfo.setBackground(COLOR_BG);
        JLabel lblUser = new JLabel("Khách hàng: " + currentUser.getHoTen());
        lblUser.setForeground(Color.LIGHT_GRAY);
        pnlUserInfo.add(lblUser);

        pnlFooterWrapper.add(pnlBottom, BorderLayout.CENTER);
        pnlFooterWrapper.add(pnlUserInfo, BorderLayout.SOUTH);

        add(pnlFooterWrapper, BorderLayout.SOUTH);
    }

    private void xuLyHuyDon() {
        int selectedRow = tableDonHang.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn đơn hàng cần hủy!", "Thông báo",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int modelRow = tableDonHang.convertRowIndexToModel(selectedRow);
        String donHangId = tableModel.getValueAt(modelRow, 0).toString();
        String trangThai = tableModel.getValueAt(modelRow, 3).toString();

        if (trangThai.equalsIgnoreCase("ĐÃ HỦY")) {
            JOptionPane.showMessageDialog(this, "Đơn hàng này đã bị hủy trước đó!", "Thông báo",
                    JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        if (trangThai.equalsIgnoreCase("HOÀN THÀNH") || trangThai.equalsIgnoreCase("ĐANG GIAO")) {
            JOptionPane.showMessageDialog(this, "Không thể hủy đơn hàng đang giao hoặc đã giao!", "Cảnh báo",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn hủy đơn hàng " + donHangId + "?",
                "Xác nhận hủy", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = donHangBLL.capNhatTrangThai(donHangId, "ĐÃ HỦY");
            if (success) {
                JOptionPane.showMessageDialog(this, "Đã hủy đơn hàng thành công.");
                loadData();
            } else {
                JOptionPane.showMessageDialog(this, "Lỗi khi hủy đơn hàng. Vui lòng thử lại.", "Lỗi",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Chỉ mở form đánh giá khi đơn đã hoàn thành và khách chưa đánh giá đơn này.
     * Dữ liệu nhập từ dialog sẽ được chuyển qua BLL để ghi xuống bảng DanhGia.
     */
    private void xuLyDanhGia() {
        int selectedRow = tableDonHang.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn đơn hàng cần đánh giá!", "Thông báo",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int modelRow = tableDonHang.convertRowIndexToModel(selectedRow);
        String donHangId = tableModel.getValueAt(modelRow, 0).toString();
        String trangThai = tableModel.getValueAt(modelRow, 3).toString();
        String tinhTrangDanhGia = tableModel.getValueAt(modelRow, 5).toString();
        String quanAnId = tableModel.getValueAt(modelRow, 7).toString();

        if (!"HOÀN THÀNH".equalsIgnoreCase(trangThai)) {
            JOptionPane.showMessageDialog(this, "Chỉ có thể đánh giá đơn hàng đã hoàn thành.", "Cảnh báo",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        if ("Đã đánh giá".equalsIgnoreCase(tinhTrangDanhGia)
                || danhGiaBLL.daDanhGiaDonHang(donHangId, currentUser.getNguoiDungId())) {
            JOptionPane.showMessageDialog(this, "Đơn hàng này đã được đánh giá.", "Thông báo",
                    JOptionPane.INFORMATION_MESSAGE);
            loadData();
            return;
        }

        FrmDanhGiaDonHang frmDanhGia = new FrmDanhGiaDonHang(this, donHangId);
        FrmDanhGiaDonHang.KetQuaDanhGia ketQua = frmDanhGia.hienThi();
        if (ketQua != null) {
            boolean ok = danhGiaBLL.themDanhGia(donHangId, currentUser.getNguoiDungId(), quanAnId,
                    ketQua.getSoSao(), ketQua.getNoiDung());
            if (ok) {
                JOptionPane.showMessageDialog(this, "Cảm ơn bạn đã đánh giá đơn hàng.");
                loadData();
            } else {
                JOptionPane.showMessageDialog(this, "Không thể lưu đánh giá. Vui lòng kiểm tra dữ liệu hoặc thử lại.",
                        "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public void loadData() {
        tableModel.setRowCount(0);
        List<DonHang> danhSach = donHangBLL.layLichSuDonHang(currentUser.getNguoiDungId());

        for (DonHang dh : danhSach) {
            boolean daDanhGia = danhGiaBLL.daDanhGiaDonHang(dh.getDonHangId(), currentUser.getNguoiDungId());
            Object[] row = {
                    dh.getDonHangId(),
                    dfDate.format(dh.getThoiGianDat()),
                    dfMoney.format(dh.getTongTien()),
                    dh.getTrangThai(),
                    taoNhanThanhToan(dh),
                    daDanhGia ? "Đã đánh giá" : "Chưa đánh giá",
                    dh.getDiaChiGiao(),
                    dh.getQuanAnId()
            };
            tableModel.addRow(row);
        }
    }

    private String taoNhanThanhToan(DonHang dh) {
        String phuongThuc = dh.getPhuongThucThanhToan();
        String trangThai = dh.getTrangThaiThanhToan();
        if (phuongThuc == null || phuongThuc.trim().isEmpty()) {
            phuongThuc = "Tiền mặt";
        }
        if (trangThai == null || trangThai.trim().isEmpty()) {
            trangThai = "CHƯA THANH TOÁN";
        }
        return phuongThuc + " - " + trangThai;
    }

    private static void styleButton(JButton btn, Color bg, Color border, Dimension size) {
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setFocusPainted(false);
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createLineBorder(border, 1));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        if (size != null) btn.setPreferredSize(size);
    }
}
