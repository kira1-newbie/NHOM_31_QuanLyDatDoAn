package GUI;

import BusinessLogic.DonHangBLL;
import SCHEMA.DonHang;
import SCHEMA.NguoiDung;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;

public class FrmDonHangCuaToi extends JFrame {

    private NguoiDung currentUser;
    private DonHangBLL donHangBLL = new DonHangBLL();

    // Các thành phần UI
    private JTable tableDonHang;
    private DefaultTableModel tableModel;

    private final Color COLOR_PRIMARY = new Color(238, 77, 45);
    private final DecimalFormat dfMoney = new DecimalFormat("#,### VNĐ");
    private final SimpleDateFormat dfDate = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    public FrmDonHangCuaToi(NguoiDung user) {
        this.currentUser = user;
        initUI();
        loadData();
    }

    /**
     * 1. Khởi tạo giao diện (Header, Bảng dữ liệu)
     */
    private void initUI() {
        setTitle("Lịch Sử Đơn Hàng");
        setSize(850, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // --- Phần Header ---
        JPanel pnlHeader = new JPanel();
        pnlHeader.setBackground(Color.WHITE);
        pnlHeader.setBorder(new EmptyBorder(15, 20, 15, 20));
        JLabel lblTitle = new JLabel("📋 Đơn Hàng Của Tôi");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(COLOR_PRIMARY);
        pnlHeader.add(lblTitle);
        add(pnlHeader, BorderLayout.NORTH);

        // --- Phần Bảng dữ liệu (JTable) ---
        String[] columns = {"Mã Đơn", "Thời Gian Đặt", "Tổng Tiền", "Trạng Thái", "Địa Chỉ Giao"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Khóa không cho người dùng sửa trực tiếp trên bảng
            }
        };

        tableDonHang = new JTable(tableModel);
        tableDonHang.setRowHeight(30);
        tableDonHang.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tableDonHang.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));

        // Căn chỉnh độ rộng các cột cho đẹp mắt
        tableDonHang.getColumnModel().getColumn(0).setPreferredWidth(80);  // Mã Đơn
        tableDonHang.getColumnModel().getColumn(1).setPreferredWidth(150); // Thời Gian
        tableDonHang.getColumnModel().getColumn(2).setPreferredWidth(120); // Tổng Tiền
        tableDonHang.getColumnModel().getColumn(3).setPreferredWidth(150); // Trạng Thái
        tableDonHang.getColumnModel().getColumn(4).setPreferredWidth(250); // Địa Chỉ

        JScrollPane scrollPane = new JScrollPane(tableDonHang);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        add(scrollPane, BorderLayout.CENTER);

        // --- Phần Bottom ---
        JPanel pnlBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pnlBottom.setBorder(new EmptyBorder(10, 20, 20, 20));
        JButton btnDong = new JButton("Đóng");
        btnDong.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnDong.addActionListener(e -> this.dispose());
        pnlBottom.add(btnDong);
        add(pnlBottom, BorderLayout.SOUTH);
    }

    /**
     * 2. Lấy dữ liệu từ CSDL nạp vào bảng
     */
    private void loadData() {
        tableModel.setRowCount(0); // Làm sạch bảng

        // Gọi BLL lấy danh sách đơn hàng của User đang đăng nhập
        List<DonHang> danhSach = donHangBLL.layLichSuDonHang(currentUser.getNguoiDungId());

        for (DonHang dh : danhSach) {
            Object[] row = {
                    dh.getDonHangId(),
                    dfDate.format(dh.getThoiGianDat()),
                    dfMoney.format(dh.getTongTien()),
                    dh.getTrangThai(),
                    dh.getDiaChiGiao()
            };
            tableModel.addRow(row);
        }
    }
}