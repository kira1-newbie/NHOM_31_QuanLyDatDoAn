package GUI;

import BusinessLogic.ShipperBLL;
import SCHEMA.DonHang;
import SCHEMA.NguoiDung;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;

public class FrmShipper extends JFrame {

    private NguoiDung currentUser;
    private ShipperBLL shipperBLL = new ShipperBLL();

    private JTable tableDonHang;
    private DefaultTableModel tableModel;
    private JButton btnNhanDon;
    private JButton btnLamMoi;

    private final Color COLOR_PRIMARY = new Color(238, 77, 45); // Cam FoodApp
    private final DecimalFormat dfMoney = new DecimalFormat("#,### VNĐ");
    private final SimpleDateFormat dfDate = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    public FrmShipper(NguoiDung user) {
        this.currentUser = user;
        initUI();
        loadData();
    }

    /**
     * 1. Khởi tạo giao diện
     */
    private void initUI() {
        setTitle("Cổng Dành Cho Đối Tác Giao Hàng (Shipper)");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // --- Header ---
        JPanel pnlHeader = new JPanel(new BorderLayout());
        pnlHeader.setBackground(Color.WHITE);
        pnlHeader.setBorder(new EmptyBorder(15, 20, 15, 20));

        JLabel lblTitle = new JLabel("🛵 Danh Sách Đơn Hàng Cần Giao");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(COLOR_PRIMARY);
        pnlHeader.add(lblTitle, BorderLayout.WEST);

        btnLamMoi = new JButton("🔄 Làm Mới");
        btnLamMoi.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnLamMoi.setBackground(Color.WHITE);
        btnLamMoi.setForeground(COLOR_PRIMARY);
        btnLamMoi.setFocusPainted(false);
        btnLamMoi.addActionListener(e -> loadData());
        pnlHeader.add(btnLamMoi, BorderLayout.EAST);

        add(pnlHeader, BorderLayout.NORTH);

        // --- Bảng Dữ Liệu ---
        String[] columns = {"Mã Đơn", "Thời Gian Đặt", "Tổng Tiền", "Địa Chỉ Giao", "Trạng Thái"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableDonHang = new JTable(tableModel);
        tableDonHang.setRowHeight(30);
        tableDonHang.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tableDonHang.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        // Chỉ cho phép chọn 1 dòng tại 1 thời điểm
        tableDonHang.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(tableDonHang);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        add(scrollPane, BorderLayout.CENTER);

        // --- Bottom ---
        JPanel pnlBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pnlBottom.setBorder(new EmptyBorder(10, 20, 20, 20));

        btnNhanDon = new JButton("NHẬN GIAO ĐƠN NÀY");
        btnNhanDon.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnNhanDon.setBackground(COLOR_PRIMARY);
        btnNhanDon.setForeground(Color.WHITE);
        btnNhanDon.setPreferredSize(new Dimension(220, 40));
        btnNhanDon.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btnNhanDon.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xuLyNhanDon();
            }
        });

        pnlBottom.add(btnNhanDon);
        add(pnlBottom, BorderLayout.SOUTH);
    }

    /**
     * 2. Lấy dữ liệu danh sách đơn hàng nạp vào bảng
     */
    private void loadData() {
        tableModel.setRowCount(0);
        List<DonHang> danhSach = shipperBLL.layDanhSachDonCho();

        for (DonHang dh : danhSach) {
            Object[] row = {
                    dh.getDonHangId(),
                    dfDate.format(dh.getThoiGianDat()),
                    dfMoney.format(dh.getTongTien()),
                    dh.getDiaChiGiao(),
                    dh.getTrangThai()
            };
            tableModel.addRow(row);
        }
    }

    /**
     * 3. Xử lý logic khi Shipper bấm nhận đơn
     */
    private void xuLyNhanDon() {
        int selectedRow = tableDonHang.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn một đơn hàng trong bảng để nhận giao!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Lấy Mã Đơn Hàng từ cột đầu tiên (index 0) của dòng đang được chọn
        String donHangId = tableModel.getValueAt(selectedRow, 0).toString();

        int confirm = JOptionPane.showConfirmDialog(this, "Bạn chắc chắn muốn nhận giao đơn hàng " + donHangId + "?", "Xác nhận", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // Gọi BLL xử lý
            boolean thanhCong = shipperBLL.nhanDonGiao(donHangId, currentUser.getNguoiDungId());

            if (thanhCong) {
                JOptionPane.showMessageDialog(this, "Nhận đơn thành công! Trạng thái đơn đã chuyển sang ĐANG GIAO.");
                loadData(); // Tải lại bảng để làm mất đi đơn hàng vừa nhận
            } else {
                JOptionPane.showMessageDialog(this, "Lỗi khi nhận đơn. Có thể đơn hàng đã bị người khác nhận.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}