package GUI;

import BusinessLogic.DonHangBLL;
import SCHEMA.NguoiDung;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

public class FrmGioHang extends JFrame {

    private NguoiDung currentUser;
    private String gioHangId;

    // Tầng BLL
    private DonHangBLL donHangBLL = new DonHangBLL();
    private BusinessLogic.GioHangBLL gioHangBLL = new BusinessLogic.GioHangBLL(); // Đã kích hoạt
    // (Lưu ý: Bạn sẽ cần bổ sung hàm layDanhSachChiTietGio() vào GioHangBLL sau)
    // private GioHangBLL gioHangBLL = new GioHangBLL();

    // Các thành phần UI
    private JTable tableGioHang;
    private DefaultTableModel tableModel;
    private JLabel lblTongTien;
    private JTextField txtDiaChi;

    private final Color COLOR_PRIMARY = new Color(238, 77, 45); // Cam FoodApp
    private final DecimalFormat df = new DecimalFormat("#,### VNĐ");

    public FrmGioHang(NguoiDung user) {
        this.currentUser = user;
        // Giả lập mã giỏ hàng từ mã người dùng (Giống bên FrmThucDon)
        this.gioHangId = "GH" + currentUser.getNguoiDungId().substring(3);

        initUI();
        loadDataToTable(); // Nạp dữ liệu
    }

    /**
     * 1. Khởi tạo Giao diện Giỏ Hàng
     */
    private void initUI() {
        setTitle("Giỏ Hàng Của Bạn");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // --- HEADER ---
        JPanel pnlHeader = new JPanel();
        pnlHeader.setBackground(Color.WHITE);
        pnlHeader.setBorder(new EmptyBorder(15, 20, 15, 20));
        JLabel lblTitle = new JLabel("🛒 Chi Tiết Giỏ Hàng");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(COLOR_PRIMARY);
        pnlHeader.add(lblTitle);
        add(pnlHeader, BorderLayout.NORTH);

        // --- CENTER (Bảng dữ liệu) ---
        // Thiết lập cấu trúc cột cho bảng
        String[] columns = {"Mã SP", "Tên Món Ăn", "Đơn Giá", "Số Lượng", "Thành Tiền"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Không cho phép gõ trực tiếp vào ô để sửa
            }
        };
        tableGioHang = new JTable(tableModel);
        tableGioHang.setRowHeight(30);
        tableGioHang.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tableGioHang.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));

        JScrollPane scrollPane = new JScrollPane(tableGioHang);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        add(scrollPane, BorderLayout.CENTER);

        // --- BOTTOM (Thanh toán & Địa chỉ) ---
        JPanel pnlBottom = new JPanel(new BorderLayout());
        pnlBottom.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Khung nhập địa chỉ
        JPanel pnlDiaChi = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblDiaChi = new JLabel("Địa chỉ giao hàng:");
        lblDiaChi.setFont(new Font("Segoe UI", Font.BOLD, 14));
        txtDiaChi = new JTextField(30);
        txtDiaChi.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        pnlDiaChi.add(lblDiaChi);
        pnlDiaChi.add(txtDiaChi);
        pnlBottom.add(pnlDiaChi, BorderLayout.WEST);

        // Khung hiển thị tổng tiền & Nút chốt đơn
        JPanel pnlThanhToan = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        lblTongTien = new JLabel("Tổng cộng: 0 VNĐ");
        lblTongTien.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTongTien.setForeground(COLOR_PRIMARY);

        JButton btnDatHang = new JButton("XÁC NHẬN ĐẶT HÀNG");
        btnDatHang.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnDatHang.setBackground(COLOR_PRIMARY);
        btnDatHang.setForeground(Color.WHITE);
        btnDatHang.setPreferredSize(new Dimension(200, 40));
        btnDatHang.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Sự kiện: Bấm đặt hàng
        btnDatHang.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xuLyDatHang();
            }
        });

        pnlThanhToan.add(lblTongTien);
        pnlThanhToan.add(btnDatHang);
        pnlBottom.add(pnlThanhToan, BorderLayout.EAST);

        add(pnlBottom, BorderLayout.SOUTH);
    }

    /**
     * 2. Tải dữ liệu giả lập (Mock Data) lên bảng
     * (Sau này sẽ gọi BLL để kéo từ Database)
     */
    /**
     * 2. Tải dữ liệu thật từ Database lên bảng
     */
    private void loadDataToTable() {
        tableModel.setRowCount(0); // Xóa trắng bảng trước khi nạp
        double tongTien = 0;

        // Gọi BLL để lấy dữ liệu thực tế
        java.util.List<SCHEMA.ChiTietGioHangDTO> danhSach = gioHangBLL.layDanhSachChiTietGio(gioHangId);

        if (danhSach.isEmpty()) {
            lblTongTien.setText("Giỏ hàng trống");
            return;
        }

        // Đổ dữ liệu vào JTable
        for (SCHEMA.ChiTietGioHangDTO dto : danhSach) {
            Object[] row = {
                    dto.getSanPhamId(),
                    dto.getTenSanPham(),
                    df.format(dto.getDonGia()),
                    dto.getSoLuong(),
                    df.format(dto.getThanhTien())
            };
            tableModel.addRow(row);

            // Cộng dồn tổng tiền
            tongTien += dto.getThanhTien();
        }

        // Hiển thị tổng tiền
        lblTongTien.setText("Tổng cộng: " + df.format(tongTien));
    }
    /**
     * 3. Xử lý logic Đặt Hàng thông qua BLL
     */
    private void xuLyDatHang() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Giỏ hàng đang trống!");
            return;
        }

        String diaChi = txtDiaChi.getText().trim();
        if (diaChi.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập địa chỉ giao hàng!", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            txtDiaChi.requestFocus();
            return;
        }

        // Đổi nút thành Loading
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn đặt đơn hàng này?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            // Gọi BLL (Đã được viết ở các bước trước)
            boolean thanhCong = donHangBLL.datHang(currentUser.getNguoiDungId(), gioHangId, diaChi);

            if (thanhCong) {
                JOptionPane.showMessageDialog(this, "Đặt hàng thành công! Vui lòng chờ quán xác nhận.");
                tableModel.setRowCount(0); // Xóa giỏ
                lblTongTien.setText("Tổng cộng: 0 VNĐ");
                this.dispose(); // Đóng form giỏ hàng
            } else {
                JOptionPane.showMessageDialog(this, "Đặt hàng thất bại. Vui lòng kiểm tra lại hệ thống.");
            }
        }
    }
}