package ProcessData;

import ConnectionData.CONNECTIONSQLSERVER;
import SCHEMA.DanhGia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DanhGiaDAO {

    public boolean daDanhGiaDonHang(String donHangId, String khachHangId) {
        String sql = "SELECT 1 FROM DanhGia WHERE DonHangId = ? AND KhachHangId = ?";
        try (Connection conn = CONNECTIONSQLSERVER.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, donHangId);
            ps.setString(2, khachHangId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return true;
        }
    }

    public boolean themDanhGia(DanhGia danhGia) {
        String sql = "INSERT INTO DanhGia (DanhGiaId, DonHangId, KhachHangId, QuanAnId, SoSao, NoiDung) " +
                "VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = CONNECTIONSQLSERVER.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, danhGia.getDanhGiaId());
            ps.setString(2, danhGia.getDonHangId());
            ps.setString(3, danhGia.getKhachHangId());
            ps.setString(4, danhGia.getQuanAnId());
            ps.setInt(5, danhGia.getSoSao());
            ps.setString(6, danhGia.getNoiDung());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<DanhGia> layDanhGiaTheoQuan(String quanAnId) {
        List<DanhGia> list = new ArrayList<>();
        String sql = "SELECT * FROM DanhGia WHERE QuanAnId = ? ORDER BY ThoiGianDanhGia DESC";
        try (Connection conn = CONNECTIONSQLSERVER.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, quanAnId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    DanhGia dg = new DanhGia();
                    dg.setDanhGiaId(rs.getString("DanhGiaId"));
                    dg.setDonHangId(rs.getString("DonHangId"));
                    dg.setKhachHangId(rs.getString("KhachHangId"));
                    dg.setQuanAnId(rs.getString("QuanAnId"));
                    dg.setSoSao(rs.getInt("SoSao"));
                    dg.setNoiDung(rs.getString("NoiDung"));
                    dg.setThoiGianDanhGia(rs.getTimestamp("ThoiGianDanhGia"));
                    list.add(dg);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
