package ProcessData;

import ConnectionData.CONNECTIONSQLSERVER;
import java.sql.CallableStatement;
import java.sql.Connection;

public class GioHangDAO {

    /**
     * Thêm sản phẩm vào giỏ hàng
     */
    public boolean themVaoGioHang(String gioHangId, String sanPhamId, int soLuong) {
        String sql = "{call sp_ThemGioHang(?, ?, ?)}";
        boolean isSuccess = false;

        try (Connection conn = CONNECTIONSQLSERVER.getConnection();
             CallableStatement cs = conn.prepareCall(sql)) {

            cs.setString(1, gioHangId);
            cs.setString(2, sanPhamId);
            cs.setInt(3, soLuong);

            int rowsAffected = cs.executeUpdate();
            isSuccess = rowsAffected > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return isSuccess;
    }
    /**
     * Lấy danh sách chi tiết giỏ hàng kết hợp với thông tin Sản Phẩm
     */
    public java.util.List<SCHEMA.ChiTietGioHangDTO> layDanhSachChiTietGio(String gioHangId) {
        java.util.List<SCHEMA.ChiTietGioHangDTO> list = new java.util.ArrayList<>();

        // Câu lệnh SQL JOIN 2 bảng ChiTietGioHang và SanPham
        String sql = "SELECT ct.SanPhamId, sp.TenSanPham, sp.Gia, ct.SoLuong, (sp.Gia * ct.SoLuong) AS ThanhTien " +
                "FROM ChiTietGioHang ct " +
                "JOIN SanPham sp ON ct.SanPhamId = sp.SanPhamId " +
                "WHERE ct.GioHangId = ?";

        try (java.sql.Connection conn = ConnectionData.CONNECTIONSQLSERVER.getConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, gioHangId);
            java.sql.ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                SCHEMA.ChiTietGioHangDTO dto = new SCHEMA.ChiTietGioHangDTO();
                dto.setSanPhamId(rs.getString("SanPhamId"));
                dto.setTenSanPham(rs.getString("TenSanPham"));
                dto.setDonGia(rs.getDouble("Gia"));
                dto.setSoLuong(rs.getInt("SoLuong"));
                dto.setThanhTien(rs.getDouble("ThanhTien"));

                list.add(dto);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}