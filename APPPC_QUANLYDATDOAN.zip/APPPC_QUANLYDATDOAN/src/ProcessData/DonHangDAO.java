package ProcessData;

import ConnectionData.CONNECTIONSQLSERVER;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class DonHangDAO {

    public boolean taoDonHang(String donHangId, String khachHangId, String gioHangId, String diaChiGiao) {
        return taoDonHang(donHangId, khachHangId, gioHangId, diaChiGiao, "Tiền mặt", "CHƯA THANH TOÁN");
    }

    public boolean taoDonHang(String donHangId, String khachHangId, String gioHangId, String diaChiGiao,
                              String phuongThucThanhToan, String trangThaiThanhToan) {
        String sql = "{call sp_TaoDonHang(?, ?, ?, ?)}";

        if (!cotThanhToanDaSanSang()) {
            System.err.println("Thiếu cột thanh toán trong bảng DonHang. Hãy chạy script database/2026_05_20_add_payment_and_reviews.sql trước.");
            return false;
        }

        try (Connection conn = CONNECTIONSQLSERVER.getConnection();
             CallableStatement cs = conn.prepareCall(sql)) {

            cs.setString(1, donHangId);
            cs.setString(2, khachHangId);
            cs.setString(3, gioHangId);
            cs.setString(4, diaChiGiao);

            cs.executeUpdate();
            return capNhatThanhToan(donHangId, phuongThucThanhToan, trangThaiThanhToan);

        } catch (Exception e) {
            System.err.println("Lỗi khi tạo đơn hàng: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private boolean cotThanhToanDaSanSang() {
        String sql = "SELECT COL_LENGTH('DonHang', 'PhuongThucThanhToan') AS CotPhuongThuc, " +
                "COL_LENGTH('DonHang', 'TrangThaiThanhToan') AS CotTrangThai";
        try (Connection conn = CONNECTIONSQLSERVER.getConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return rs.getObject("CotPhuongThuc") != null && rs.getObject("CotTrangThai") != null;
            }
        } catch (Exception e) {
            System.err.println("Không kiểm tra được cấu trúc thanh toán: " + e.getMessage());
        }
        return false;
    }

    private boolean capNhatThanhToan(String donHangId, String phuongThucThanhToan, String trangThaiThanhToan) {
        String sqlUpdateDon = "UPDATE DonHang SET PhuongThucThanhToan = ?, TrangThaiThanhToan = ? WHERE DonHangId = ?";
        String sqlTongTien = "SELECT TongTien FROM DonHang WHERE DonHangId = ?";
        String sqlTonTaiThanhToan = "SELECT 1 FROM ThanhToan WHERE DonHangId = ?";
        String sqlInsertThanhToan = "INSERT INTO ThanhToan (ThanhToanId, DonHangId, PhuongThuc, SoTien, TrangThai) VALUES (?, ?, ?, ?, ?)";
        String sqlUpdateThanhToan = "UPDATE ThanhToan SET PhuongThuc = ?, SoTien = ?, TrangThai = ? WHERE DonHangId = ?";

        try (Connection conn = CONNECTIONSQLSERVER.getConnection()) {
            conn.setAutoCommit(false);

            double tongTien = 0;
            try (java.sql.PreparedStatement ps = conn.prepareStatement(sqlTongTien)) {
                ps.setString(1, donHangId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        tongTien = rs.getDouble("TongTien");
                    } else {
                        conn.rollback();
                        return false;
                    }
                }
            }

            try (java.sql.PreparedStatement ps = conn.prepareStatement(sqlUpdateDon)) {
                ps.setString(1, phuongThucThanhToan);
                ps.setString(2, trangThaiThanhToan);
                ps.setString(3, donHangId);
                if (ps.executeUpdate() <= 0) {
                    conn.rollback();
                    return false;
                }
            }

            boolean daCoThanhToan = false;
            try (java.sql.PreparedStatement ps = conn.prepareStatement(sqlTonTaiThanhToan)) {
                ps.setString(1, donHangId);
                try (ResultSet rs = ps.executeQuery()) {
                    daCoThanhToan = rs.next();
                }
            }

            if (daCoThanhToan) {
                try (java.sql.PreparedStatement ps = conn.prepareStatement(sqlUpdateThanhToan)) {
                    ps.setString(1, phuongThucThanhToan);
                    ps.setDouble(2, tongTien);
                    ps.setString(3, trangThaiThanhToan);
                    ps.setString(4, donHangId);
                    ps.executeUpdate();
                }
            } else {
                try (java.sql.PreparedStatement ps = conn.prepareStatement(sqlInsertThanhToan)) {
                    ps.setString(1, taoThanhToanId(donHangId));
                    ps.setString(2, donHangId);
                    ps.setString(3, phuongThucThanhToan);
                    ps.setDouble(4, tongTien);
                    ps.setString(5, trangThaiThanhToan);
                    ps.executeUpdate();
                }
            }

            conn.commit();
            return true;
        } catch (Exception e) {
            System.err.println("Lỗi cập nhật thanh toán: " + e.getMessage());
            return false;
        }
    }

    private String taoThanhToanId(String donHangId) {
        if (donHangId != null && donHangId.length() >= 7) {
            return "TT" + donHangId.substring(2);
        }
        return "TT" + (10000 + new java.util.Random().nextInt(90000));
    }

    public java.util.List<SCHEMA.DonHang> layDanhSachDonHangTheoKhach(String khachHangId) {
        java.util.List<SCHEMA.DonHang> list = new java.util.ArrayList<>();
        String sql = "SELECT * FROM DonHang WHERE KhachHangId = ? ORDER BY ThoiGianDat DESC";

        try (Connection conn = CONNECTIONSQLSERVER.getConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, khachHangId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapDonHang(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public java.util.List<SCHEMA.DonHang> layDanhSachDonHangTheoQuan(String quanAnId) {
        java.util.List<SCHEMA.DonHang> list = new java.util.ArrayList<>();
        String sql = "SELECT * FROM DonHang WHERE QuanAnId = ? ORDER BY ThoiGianDat DESC";

        try (Connection conn = CONNECTIONSQLSERVER.getConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, quanAnId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapDonHang(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean capNhatTrangThaiDon(String donHangId, String trangThaiMoi) {
        String sql = "{call sp_CapNhatTrangThaiDon(?, ?)}";
        try (Connection conn = CONNECTIONSQLSERVER.getConnection();
             CallableStatement cs = conn.prepareCall(sql)) {

            cs.setString(1, donHangId);
            cs.setString(2, trangThaiMoi);
            return cs.executeUpdate() > 0;

        } catch (Exception e) {
            System.err.println("Lỗi cập nhật trạng thái đơn: " + e.getMessage());
            return false;
        }
    }

    public double[] thongKeDoanhThuQuanAn(String quanAnId) {
        double[] ketQua = new double[2];
        String sql = "SELECT COUNT(DonHangId) AS TongSoDon, SUM(TongTien) AS TongDoanhThu " +
                "FROM DonHang WHERE QuanAnId = ? AND TrangThai = N'HOÀN THÀNH'";

        try (Connection conn = CONNECTIONSQLSERVER.getConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, quanAnId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ketQua[0] = rs.getDouble("TongSoDon");
                    ketQua[1] = rs.getDouble("TongDoanhThu");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ketQua;
    }

    private SCHEMA.DonHang mapDonHang(ResultSet rs) throws java.sql.SQLException {
        SCHEMA.DonHang dh = new SCHEMA.DonHang();
        dh.setDonHangId(rs.getString("DonHangId"));
        dh.setKhachHangId(rs.getString("KhachHangId"));
        dh.setQuanAnId(rs.getString("QuanAnId"));
        dh.setDiaChiGiao(rs.getString("DiaChiGiao"));
        dh.setTongTien(rs.getDouble("TongTien"));
        dh.setTrangThai(rs.getString("TrangThai"));
        dh.setThoiGianDat(rs.getTimestamp("ThoiGianDat"));

        if (hasColumn(rs, "PhuongThucThanhToan")) {
            dh.setPhuongThucThanhToan(rs.getString("PhuongThucThanhToan"));
        }
        if (hasColumn(rs, "TrangThaiThanhToan")) {
            dh.setTrangThaiThanhToan(rs.getString("TrangThaiThanhToan"));
        }

        return dh;
    }

    private boolean hasColumn(ResultSet rs, String columnName) throws java.sql.SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        for (int i = 1; i <= metaData.getColumnCount(); i++) {
            if (columnName.equalsIgnoreCase(metaData.getColumnName(i))) {
                return true;
            }
        }
        return false;
    }
}
