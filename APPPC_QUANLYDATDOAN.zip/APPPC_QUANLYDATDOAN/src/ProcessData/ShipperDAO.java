package ProcessData;

import ConnectionData.CONNECTIONSQLSERVER;
import SCHEMA.DonHang;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ShipperDAO {

    /**
     * Lấy danh sách các đơn hàng chưa có người giao
     */
    public List<DonHang> layDanhSachDonChuaGiao() {
        List<DonHang> list = new ArrayList<>();
        // Lấy các đơn hàng đang chờ xử lý
        String sql = "SELECT * FROM DonHang WHERE TrangThai IN (N'CHỜ XÁC NHẬN', N'ĐÃ XÁC NHẬN') ORDER BY ThoiGianDat ASC";

        try (Connection conn = CONNECTIONSQLSERVER.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                DonHang dh = new DonHang();
                dh.setDonHangId(rs.getString("DonHangId"));
                dh.setKhachHangId(rs.getString("KhachHangId"));
                dh.setQuanAnId(rs.getString("QuanAnId"));
                dh.setDiaChiGiao(rs.getString("DiaChiGiao"));
                dh.setTongTien(rs.getDouble("TongTien"));
                dh.setTrangThai(rs.getString("TrangThai"));
                dh.setThoiGianDat(rs.getTimestamp("ThoiGianDat"));

                list.add(dh);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    /**
     * Gọi thủ tục cập nhật Shipper nhận đơn
     */
    public boolean nhanDonHang(String giaoHangId, String donHangId, String shipperId) {
        String sql = "{call sp_ShipperNhanDon(?, ?, ?)}";
        boolean isSuccess = false;

        try (Connection conn = CONNECTIONSQLSERVER.getConnection();
             CallableStatement cs = conn.prepareCall(sql)) {

            cs.setString(1, giaoHangId);
            cs.setString(2, donHangId);
            cs.setString(3, shipperId);

            cs.executeUpdate();
            isSuccess = true;

        } catch (Exception e) {
            System.err.println("Lỗi khi Shipper nhận đơn: " + e.getMessage());
            e.printStackTrace();
        }
        return isSuccess;
    }
}