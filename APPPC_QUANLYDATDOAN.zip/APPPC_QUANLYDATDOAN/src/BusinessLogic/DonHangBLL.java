package BusinessLogic;

import ProcessData.DonHangDAO;
import java.util.Random;

public class DonHangBLL {
    private DonHangDAO donHangDAO = new DonHangDAO();

    public boolean datHang(String khachHangId, String gioHangId, String diaChiGiao) {
        return datHang(khachHangId, gioHangId, diaChiGiao, "Tiền mặt");
    }

    public boolean datHang(String khachHangId, String gioHangId, String diaChiGiao, String phuongThucThanhToan) {
        if (khachHangId == null || khachHangId.trim().isEmpty()) {
            System.out.println("Mã khách hàng không hợp lệ.");
            return false;
        }
        if (gioHangId == null || gioHangId.trim().isEmpty()) {
            System.out.println("Mã giỏ hàng không hợp lệ.");
            return false;
        }
        if (diaChiGiao == null || diaChiGiao.trim().isEmpty()) {
            System.out.println("Địa chỉ giao hàng không được để trống.");
            return false;
        }
        if (phuongThucThanhToan == null || phuongThucThanhToan.trim().isEmpty()) {
            System.out.println("Phương thức thanh toán không hợp lệ.");
            return false;
        }

        String trangThaiThanhToan = "Tiền mặt".equals(phuongThucThanhToan)
                ? "CHƯA THANH TOÁN"
                : "ĐÃ THANH TOÁN";

        Random random = new Random();
        int randomNumber = 10000 + random.nextInt(90000);
        String donHangId = "DH" + randomNumber;

        boolean ketQua = donHangDAO.taoDonHang(donHangId, khachHangId, gioHangId, diaChiGiao,
                phuongThucThanhToan, trangThaiThanhToan);

        if (ketQua) {
            System.out.println("Đặt hàng thành công! Mã đơn: " + donHangId);
        } else {
            System.out.println("Đặt hàng thất bại. Vui lòng thử lại.");
        }

        return ketQua;
    }

    public java.util.List<SCHEMA.DonHang> layLichSuDonHang(String khachHangId) {
        if (khachHangId == null || khachHangId.trim().isEmpty()) {
            System.out.println("Lỗi: Mã khách hàng không hợp lệ.");
            return new java.util.ArrayList<>();
        }
        return donHangDAO.layDanhSachDonHangTheoKhach(khachHangId);
    }

    public java.util.List<SCHEMA.DonHang> layDanhSachDonHangQuanAn(String quanAnId) {
        if (quanAnId == null || quanAnId.trim().isEmpty()) {
            return new java.util.ArrayList<>();
        }
        return donHangDAO.layDanhSachDonHangTheoQuan(quanAnId);
    }

    public boolean capNhatTrangThai(String donHangId, String trangThaiMoi) {
        if (donHangId == null || donHangId.trim().isEmpty()) return false;
        return donHangDAO.capNhatTrangThaiDon(donHangId, trangThaiMoi);
    }

    public double[] layThongKeDoanhThu(String quanAnId) {
        if (quanAnId == null || quanAnId.trim().isEmpty()) {
            return new double[]{0, 0};
        }
        return donHangDAO.thongKeDoanhThuQuanAn(quanAnId);
    }
}
