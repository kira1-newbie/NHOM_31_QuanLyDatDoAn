package BusinessLogic;

import ProcessData.ShipperDAO;
import SCHEMA.DonHang;
import java.util.List;
import java.util.Random;

public class ShipperBLL {
    private ShipperDAO shipperDAO = new ShipperDAO();

    /**
     * Lấy danh sách các đơn hàng khả dụng để giao
     */
    public List<DonHang> layDanhSachDonCho() {
        return shipperDAO.layDanhSachDonChuaGiao();
    }

    /**
     * Xử lý nghiệp vụ Shipper nhận đơn
     */
    public boolean nhanDonGiao(String donHangId, String shipperId) {
        if (donHangId == null || donHangId.trim().isEmpty() || shipperId == null) {
            return false;
        }

        // Tạo mã Giao Hàng ngẫu nhiên (Đảm bảo độ dài CHAR(7))
        Random rand = new Random();
        int randomNumber = 10000 + rand.nextInt(90000);
        String giaoHangId = "GH" + randomNumber;

        return shipperDAO.nhanDonHang(giaoHangId, donHangId, shipperId);
    }
}