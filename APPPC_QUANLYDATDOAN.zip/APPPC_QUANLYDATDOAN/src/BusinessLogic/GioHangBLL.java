package BusinessLogic;

import ProcessData.GioHangDAO;

public class GioHangBLL {
    private GioHangDAO gioHangDAO = new GioHangDAO();

    /**
     * Xử lý thêm sản phẩm vào giỏ hàng
     */
    public boolean themVaoGio(String gioHangId, String sanPhamId, int soLuong) {
        // 1. Kiểm tra nghiệp vụ
        if (soLuong <= 0) {
            System.out.println("Số lượng thêm vào giỏ phải lớn hơn 0.");
            return false;
        }

        if (gioHangId == null || sanPhamId == null) {
            System.out.println("Thông tin giỏ hàng hoặc sản phẩm không hợp lệ.");
            return false;
        }

        // 2. Gọi DAO thực thi
        return gioHangDAO.themVaoGioHang(gioHangId, sanPhamId, soLuong);
    }
    public java.util.List<SCHEMA.ChiTietGioHangDTO> layDanhSachChiTietGio(String gioHangId) {
        if (gioHangId == null || gioHangId.trim().isEmpty()) {
            System.out.println("Mã giỏ hàng không hợp lệ.");
            return new java.util.ArrayList<>();
        }
        return gioHangDAO.layDanhSachChiTietGio(gioHangId);
    }
}