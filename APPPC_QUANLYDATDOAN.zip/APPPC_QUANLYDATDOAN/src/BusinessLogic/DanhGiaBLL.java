package BusinessLogic;

import ProcessData.DanhGiaDAO;
import SCHEMA.DanhGia;

import java.util.List;

public class DanhGiaBLL {
    private DanhGiaDAO danhGiaDAO = new DanhGiaDAO();

    public boolean daDanhGiaDonHang(String donHangId, String khachHangId) {
        if (donHangId == null || donHangId.trim().isEmpty() || khachHangId == null || khachHangId.trim().isEmpty()) {
            return true;
        }
        return danhGiaDAO.daDanhGiaDonHang(donHangId, khachHangId);
    }

    public boolean themDanhGia(String donHangId, String khachHangId, String quanAnId, int soSao, String noiDung) {
        if (donHangId == null || donHangId.trim().isEmpty()) return false;
        if (khachHangId == null || khachHangId.trim().isEmpty()) return false;
        if (quanAnId == null || quanAnId.trim().isEmpty()) return false;
        if (soSao < 1 || soSao > 5) return false;
        if (daDanhGiaDonHang(donHangId, khachHangId)) return false;

        DanhGia danhGia = new DanhGia();
        danhGia.setDanhGiaId("DG" + System.currentTimeMillis());
        danhGia.setDonHangId(donHangId);
        danhGia.setKhachHangId(khachHangId);
        danhGia.setQuanAnId(quanAnId);
        danhGia.setSoSao(soSao);
        danhGia.setNoiDung(noiDung == null ? "" : noiDung.trim());

        return danhGiaDAO.themDanhGia(danhGia);
    }

    public List<DanhGia> layDanhGiaTheoQuan(String quanAnId) {
        return danhGiaDAO.layDanhGiaTheoQuan(quanAnId);
    }
}
