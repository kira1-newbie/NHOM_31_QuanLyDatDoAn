package SCHEMA;

import java.sql.Timestamp;

public class DanhGia {
    private String danhGiaId;
    private String donHangId;
    private String khachHangId;
    private String quanAnId;
    private int soSao;
    private String noiDung;
    private Timestamp thoiGianDanhGia;

    public DanhGia() {}

    public String getDanhGiaId() { return danhGiaId; }
    public void setDanhGiaId(String danhGiaId) { this.danhGiaId = danhGiaId; }

    public String getDonHangId() { return donHangId; }
    public void setDonHangId(String donHangId) { this.donHangId = donHangId; }

    public String getKhachHangId() { return khachHangId; }
    public void setKhachHangId(String khachHangId) { this.khachHangId = khachHangId; }

    public String getQuanAnId() { return quanAnId; }
    public void setQuanAnId(String quanAnId) { this.quanAnId = quanAnId; }

    public int getSoSao() { return soSao; }
    public void setSoSao(int soSao) { this.soSao = soSao; }

    public String getNoiDung() { return noiDung; }
    public void setNoiDung(String noiDung) { this.noiDung = noiDung; }

    public Timestamp getThoiGianDanhGia() { return thoiGianDanhGia; }
    public void setThoiGianDanhGia(Timestamp thoiGianDanhGia) { this.thoiGianDanhGia = thoiGianDanhGia; }
}
